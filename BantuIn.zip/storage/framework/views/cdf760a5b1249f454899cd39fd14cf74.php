<?php $__env->startSection('title', 'Laporan Rekap Kelompok'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col">
        <div class="page-title-container mb-3">
            <div class="row">
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4" id="title">Rekap Kelompok Masyarakat</h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">Laporan</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('laporan-kelompok.index')); ?>">Rekap Kelompok</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="card mb-5">
            <div class="card-body">
                <div class="row">
                    <div class="col-12 col-lg-7 col-xxl-6 mb-3">
                        <div class="d-flex flex-wrap gap-2 align-items-center">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->user()->is_super() || auth()->user()->is_admin()): ?>
                                <div class="flex-grow-1" style="min-width: 12rem;">
                                    <select id="filter-opd" class="form-select form-select-sm">
                                        <option value="">Semua OPD</option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $opds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($opd->id); ?>"><?php echo e($opd->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </select>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <div class="flex-grow-1" style="min-width: 9rem;">
                                <select id="filter-status" class="form-select form-select-sm">
                                    <option value="">Semua Status</option>
                                    <option value="aktif">Aktif</option>
                                    <option value="nonaktif">Nonaktif</option>
                                </select>
                            </div>
                            <div class="flex-grow-1" style="min-width: 12rem;">
                                <select id="filter-belum-verifikasi" class="form-select form-select-sm">
                                    <option value="">Semua Anggota</option>
                                    <option value="1">Ada Anggota Belum Terverifikasi</option>
                                </select>
                            </div>
                            <div class="flex-grow-1 search-input-container border border-separator bg-foreground search-sm" style="min-width: 10rem;">
                                <input class="form-control form-control-sm datatable-search" placeholder="Search" data-datatable="#datatable-laporan-kelompok" />
                                <span class="search-magnifier-icon"><i data-acorn-icon="search"></i></span>
                                <span class="search-delete-icon d-none"><i data-acorn-icon="close"></i></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5 col-xxl-6 text-lg-end mb-3">
                        <div class="d-inline-flex flex-wrap gap-2 justify-content-lg-end align-items-center">
                            <button id="btn-preview" class="btn btn-sm btn-outline-secondary" type="button">
                                <i data-acorn-icon="eye"></i>
                                <span class="ms-1">Preview</span>
                            </button>
                            <button
                                class="btn btn-sm btn-outline-primary datatable-print"
                                type="button"
                                data-datatable="#datatable-laporan-kelompok"
                            >
                                <i data-acorn-icon="print"></i>
                                <span class="ms-1">Cetak</span>
                            </button>
                            <a id="btn-export" href="<?php echo e(route('laporan-kelompok.export')); ?>" class="btn btn-sm btn-outline-success">
                                <i data-acorn-icon="download"></i>
                                <span class="ms-1">Export Excel</span>
                            </a>
                            <div class="d-inline-block datatable-export" data-datatable="#datatable-laporan-kelompok">
                                <button
                                    class="btn btn-icon btn-icon-only btn-outline-muted btn-sm dropdown"
                                    data-bs-toggle="dropdown"
                                    type="button"
                                    data-bs-offset="0,3"
                                    title="Export lainnya"
                                >
                                    <i data-acorn-icon="more-horizontal"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                    <button class="dropdown-item export-copy" type="button">Copy</button>
                                    <button class="dropdown-item export-cvs" type="button">CSV</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <table
                    class="data-table data-table-pagination data-table-standard responsive nowrap stripe"
                    id="datatable-laporan-kelompok">
                    <thead>
                        <tr>
                            <th class="text-muted text-small text-uppercase">Nama Kelompok</th>
                            <th class="text-muted text-small text-uppercase">Nomor SK</th>
                            <th class="text-muted text-small text-uppercase">Tgl Pembentukan</th>
                            <th class="text-muted text-small text-uppercase">Jenis Kelompok</th>
                            <th class="text-muted text-small text-uppercase">Kecamatan</th>
                            <th class="text-muted text-small text-uppercase">Desa/Kelurahan</th>
                            <th class="text-muted text-small text-uppercase">Anggota</th>
                            <th class="text-muted text-small text-uppercase">Status</th>
                        </tr>
                    </thead>
                    <tbody class="text-alternate text-medium"></tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/vendor/datatables.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2-bootstrap4.min.css')); ?>">
    <style>
        tr.group-opd-header td {
            background: var(--bs-primary, #0d6efd) !important;
            color: #fff;
            font-weight: 600;
            font-size: 0.8rem;
            padding: 6px 10px;
            letter-spacing: 0.03em;
        }
        #datatable-laporan-kelompok tbody tr:not(.group-opd-header):not(.child) {
            cursor: pointer;
        }
        #datatable-laporan-kelompok tbody tr.shown > td:first-child::before {
            content: "▾ ";
            color: var(--bs-primary);
            font-size: 0.8rem;
        }
        #datatable-laporan-kelompok tbody tr:not(.shown):not(.group-opd-header):not(.child) > td:first-child::before {
            content: "▸ ";
            color: #aaa;
            font-size: 0.8rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_vendor'); ?>
    <script src="<?php echo e(asset('js/cs/datatable.extend.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/datatables.min.js')); ?>"></script>
    <script>
        _extendDatatables();

        const $filterOpd = $('#filter-opd');
        const $filterStatus = $('#filter-status');
        const $filterBelumVerifikasi = $('#filter-belum-verifikasi');

        [$filterOpd, $filterStatus, $filterBelumVerifikasi].forEach(function ($el) {
            if ($el.length) {
                $el.select2({ theme: 'bootstrap4', width: '100%' });
            }
        });

        const VISIBLE_COLS = 8; // jumlah kolom yang tampil (tanpa kolom opd hidden)

        const tableLaporanKelompok = $('#datatable-laporan-kelompok').DataTable({
            language: {
                paginate: {
                    previous: '<i class="cs-chevron-left"></i>',
                    next: '<i class="cs-chevron-right"></i>',
                },
            },
            buttons: ['copy', 'excel', 'csv', 'print'],
            processing: true,
            serverSide: true,
            responsive: true,
            lengthChange: true,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'Semua']],
            ordering: false,
            sDom: '<"row"<"col-sm-12"<"table-container"t>r>><"row align-items-center mt-3"<"col-sm-6"l><"col-sm-6"p>>',
            ajax: {
                url: "<?php echo route('laporan-kelompok.index'); ?>",
                data: function (d) {
                    if ($filterOpd.length) d.opd_id = $filterOpd.val();
                    d.status = $filterStatus.val();
                    d.belum_verifikasi = $filterBelumVerifikasi.val();
                },
            },
            columns: [
                { data: 'nama',           name: 'nama' },
                { data: 'nomor',          name: 'nomor' },
                { data: 'tgl_pembentukan',name: 'tgl_pembentukan', searchable: false },
                { data: 'jenis_kelompok', name: 'jenis_kelompok',  searchable: false },
                { data: 'kecamatan',      name: 'kecamatan',       searchable: false },
                { data: 'desa',           name: 'desa',            searchable: false },
                { data: 'jumlah_anggota', name: 'jumlah_anggota',  searchable: false },
                { data: 'status',         name: 'status',          searchable: false },
                { data: 'opd',            name: 'opd',             visible: false, searchable: false },
                { data: 'id',             name: 'id',              visible: false, searchable: false },
            ],
            drawCallback: function () {
                var api   = this.api();
                var rows  = api.rows({ page: 'current' }).nodes();
                var last  = null;

                api.column(8, { page: 'current' }).data().each(function (group, i) {
                    if (last !== group) {
                        $(rows).eq(i).before(
                            '<tr class="group-opd-header"><td colspan="' + VISIBLE_COLS + '">' +
                            '<i class="me-2">&#9776;</i>' + group +
                            '</td></tr>'
                        );
                        last = group;
                    }
                });
            },
        });

        $filterOpd.on('change', function () { tableLaporanKelompok.ajax.reload(); });
        $filterStatus.on('change', function () { tableLaporanKelompok.ajax.reload(); });
        $filterBelumVerifikasi.on('change', function () { tableLaporanKelompok.ajax.reload(); });

        const baseAnggotaUrl = "<?php echo url('laporan-kelompok'); ?>";

        function verifikasiBadge(a) {
            if (a.is_valid === null || a.is_valid === undefined) {
                return '<span class="badge bg-warning text-dark">' + a.status_verifikasi + '</span>';
            }
            return a.is_valid
                ? '<span class="badge bg-success">' + a.status_verifikasi + '</span>'
                : '<span class="badge bg-danger">' + a.status_verifikasi + '</span>';
        }

        function anggotaRowHtml(anggota) {
            if (!anggota.length) {
                return '<tr><td colspan="7" class="text-center text-muted fst-italic py-2">Belum ada anggota</td></tr>';
            }
            return anggota.map(function (a, i) {
                return '<tr>' +
                    '<td class="text-muted text-small" style="width:2rem">' + (i + 1) + '</td>' +
                    '<td style="width:10rem">' + a.nik + '</td>' +
                    '<td>' + a.nama + '</td>' +
                    '<td>' + a.alamat + '</td>' +
                    '<td><span class="badge bg-secondary">' + a.jabatan + '</span></td>' +
                    '<td>' + verifikasiBadge(a) + '</td>' +
                    '<td class="text-muted text-small">' + (a.keterangan !== '-' ? a.keterangan : '') + '</td>' +
                '</tr>';
            }).join('');
        }

        $('#datatable-laporan-kelompok tbody').on('click', 'tr:not(.group-opd-header):not(.child)', function () {
            var tr  = $(this);
            var row = tableLaporanKelompok.row(tr);

            if (!row.data()) { return; }

            if (row.child.isShown()) {
                row.child.hide();
                tr.removeClass('shown');
                return;
            }

            var organisasiId = row.data().id;
            var childDiv = $('<div class="p-2"><span class="text-muted fst-italic">Memuat anggota…</span></div>');
            row.child(childDiv).show();
            tr.addClass('shown');

            $.getJSON(baseAnggotaUrl + '/' + organisasiId + '/anggota', function (data) {
                childDiv.html(
                    '<table class="table table-sm table-bordered mb-0" style="background:#f8f9fa">' +
                        '<thead class="table-secondary"><tr>' +
                            '<th style="width:2rem">#</th>' +
                            '<th style="width:10rem">NIK</th>' +
                            '<th>Nama</th>' +
                            '<th>Alamat</th>' +
                            '<th>Jabatan</th>' +
                            '<th>Status Verifikasi</th>' +
                            '<th>Keterangan</th>' +
                        '</tr></thead>' +
                        '<tbody>' + anggotaRowHtml(data) + '</tbody>' +
                    '</table>'
                );
            }).fail(function () {
                childDiv.html('<span class="text-danger">Gagal memuat data anggota.</span>');
            });
        });

        $('#btn-preview').on('click', function () {
            const params = new URLSearchParams();
            if ($filterOpd.length && $filterOpd.val()) params.set('opd_id', $filterOpd.val());
            if ($filterStatus.val()) params.set('status', $filterStatus.val());
            const query = params.toString();
            window.open("<?php echo route('laporan-kelompok.preview'); ?>" + (query ? '?' + query : ''), '_blank');
        });

        $('#btn-export').on('click', function (e) {
            e.preventDefault();
            const params = new URLSearchParams();
            if ($filterOpd.length && $filterOpd.val()) params.set('opd_id', $filterOpd.val());
            if ($filterStatus.val()) params.set('status', $filterStatus.val());
            const query = params.toString();
            window.location.href = "<?php echo route('laporan-kelompok.export'); ?>" + (query ? '?' + query : '');
        });

        function _extendDatatables() {
            new DatatableExtend();
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/laporan-kelompok/index.blade.php ENDPATH**/ ?>