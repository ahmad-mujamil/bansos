
<section id="hero-slider-root" class="relative h-[870px] overflow-hidden" data-autoplay-ms="6500" aria-label="Sorotan beranda">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($heroSlides->isEmpty()): ?>
        <div class="absolute inset-0">
            <div class="absolute inset-0 bg-primary"></div>
            <div class="absolute inset-0 hero-gradient"></div>
        </div>
        <div class="relative max-w-7xl mx-auto px-8 h-full flex items-center">
            <div class="max-w-2xl space-y-6 text-left">
                <span class="inline-block px-4 py-1.5 bg-primary-container/30 text-white rounded-full text-sm font-medium backdrop-blur-sm">Program Pemerintah Resmi</span>
                <h1 class="text-5xl md:text-7xl font-bold text-white leading-[1.1] tracking-tight">
                    Gotong Royong Membangun <span class="text-on-primary-container">Kesejahteraan.</span>
                </h1>
                <p class="text-xl text-slate-200 font-light leading-relaxed">
                    Akses layanan bantuan sosial terpadu untuk masyarakat Indonesia. Transparan, akuntabel, dan tepat sasaran bagi yang membutuhkan.
                </p>
            </div>
        </div>
    <?php else: ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $heroSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $heroUrl = $slide->getFirstMediaUrl('hero');
            ?>
            <div
                data-hero-slide
                class="absolute inset-0 transition-opacity duration-700 ease-in-out <?php echo e($loop->first ? 'opacity-100 z-10' : 'opacity-0 z-0'); ?>"
                <?php if($loop->first): ?> aria-current="true" <?php endif; ?>
            >
                <div class="absolute inset-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($heroUrl !== ''): ?>
                        <img src="<?php echo e($heroUrl); ?>" alt="<?php echo e($slide->judul); ?>" class="w-full h-full object-cover"/>
                    <?php else: ?>
                        <div class="w-full h-full bg-primary"></div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="absolute inset-0 hero-gradient"></div>
                </div>
                <div class="relative max-w-7xl mx-auto px-8 h-full flex items-center">
                    <div class="max-w-2xl space-y-6 text-left">
                        <span class="inline-block px-4 py-1.5 bg-primary-container/30 text-white rounded-full text-sm font-medium backdrop-blur-sm"><?php echo e($slide->kategori); ?></span>
                        <h1 class="text-5xl md:text-7xl font-bold text-white leading-[1.1] tracking-tight">
                            <?php echo e($slide->judul); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($slide->judul_sorot)): ?> <span class="text-on-primary-container"><?php echo e($slide->judul_sorot); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </h1>
                        <p class="text-xl text-slate-200 font-light leading-relaxed">
                            <?php echo e($slide->subtitle); ?>

                        </p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</section>
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/partials/public/hero-slider.blade.php ENDPATH**/ ?>