<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>BA Verifikasi</title>
    <style>
        @page {
            margin: 36pt 44pt 48pt 44pt;
        }

        body {
            font-family: "Times New Roman", Times, serif;
            font-size: 12px;
            line-height: 1.35;
        }

        /* Footer tiap halaman (Dompdf mengulang elemen position: fixed) */
        .ba-doc-footer {
            position: fixed;
            bottom: 5pt;
            left: 44pt;
            right: 44pt;
            width: auto;
            margin: 0;
            padding: 0;
            text-align: right;
            font-size: 10px;
            font-style: italic;
            color: #4a4a4a;
        }

        .ba-doc-footer-app {
            font-weight: 700;
            font-style: italic;
        }

        /* Kop surat: tabel agar logo & teks sejajar vertikal di Dompdf */
        table.kop-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 0;
        }

        table.kop-table td.kop-logo-cell {
            width: 72px;
            vertical-align: middle;
            padding: 0 4px 0 0;
        }

        table.kop-table td.kop-text-cell {
            vertical-align: middle;
            text-align: center;
        }

        .kop-logo {
            width: 64px;
            height: auto;
            display: block;
        }

        .kop-line1 {
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .kop-line2 {
            font-size: 16px;
            font-weight: 700;
            text-transform: uppercase;
            margin-top: 2px;
        }

        .kop-line3 {
            font-size: 12px;
            margin-top: 2px;
        }

        .kop-line4 {
            font-size: 12px;
            margin-top: 2px;
        }

        .kop-line5 {
            font-size: 12px;
            margin-top: 2px;
        }

        .kop-hr {
            border-top: 1px solid #000;
            margin: 6px 0 10px;
        }

        .title {
            font-size: 14px;
            font-weight: 700;
            text-align: center;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        .section {
            margin-top: 10px;
        }

        /* Indent hierarki seperti contoh dokumen */
        .lvl-0 {
            margin-left: 0;
        }

        .lvl-1 {
            margin-left: 18px;
        }

        .lvl-2 {
            margin-left: 36px;
        }

        .row {
            margin: 2px 0;
        }

        /* Daftar data proposal: titik dua sejajar */
        table.proposal-list {
            width: 100%;
            border-collapse: collapse;
            margin-top: 4px;
        }

        table.proposal-list td {
            border: none;
            padding: 1px 0;
            vertical-align: top;
        }

        table.proposal-list td.num {
            width: 18px;
            white-space: nowrap;
        }

        table.proposal-list td.lbl {
            width: 200px;
            padding-right: 4px;
        }

        table.proposal-list td.sep {
            width: 8px;
            text-align: center;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 6px;
        }

        .table td,
        .table th {
            border: 1px solid #000;
            padding: 4px;
            vertical-align: top;
        }

        table.table-pemeriksa thead th.pemeriksa-corner {
            width: 22%;
        }

        table.table-pemeriksa thead th.pemeriksa-head {
            text-align: center;
            font-weight: 700;
        }

        table.table-pemeriksa tbody td.pemeriksa-label-col {
            text-align: left;
        }

        table.table-pemeriksa tbody td.pemeriksa-value {
            text-align: center;
        }

        table.table-pemeriksa tbody tr.pemeriksa-paraf-row td.pemeriksa-paraf-cell {
            min-height: 44px;
            height: 44px;
            vertical-align: middle;
        }

        .bold {
            font-weight: 700;
        }

        .center {
            text-align: center;
        }

        /* Kriteria verifikasi: indent + label + titik dua */
        table.kriteria-list {
            width: 100%;
            border-collapse: collapse;
            margin-top: 6px;
        }

        table.kriteria-list td {
            border: none;
            padding: 2px 0;
            vertical-align: top;
        }

        table.kriteria-list td.num {
            width: 18px;
        }

        table.kriteria-list td.lbl {
            padding-right: 6px;
        }

        table.kriteria-list td.sep {
            width: 10px;
        }

        /* Tanda tangan: blok mepet ke kanan */
        .ttd-wrap {
            margin-top: 28px;
            width: 100%;
            text-align: right;
            padding-right: 0;
        }

        .ttd-inner {
            display: inline-block;
            text-align: center;
            width: 260px;
            margin-left: 0;
        }

        .ttd-paraf {
            margin: 4px 0 2px;
            letter-spacing: 0.02em;
            line-height: 1.2;
        }

        .ttd-date-line {
            white-space: nowrap;
            font-size: 11px;
        }

        .ttd-kepala-jabatan {
            margin: 0;
        }

        /* Ruang kosong untuk tanda tangan basah antara jabatan dan nama */
        .ttd-ruang-tanda-tangan {
            min-height: 52px;
            height: 52px;
        }

        .ttd-kepala-nama {
            margin: 0;
            line-height: 1.25;
        }

        .ttd-kepala-garis {
            margin: 0;
            line-height: 1.15;
        }

        .ttd-kepala-nip {
            margin: 1px 0 0;
            line-height: 1.2;
            font-size: 11px;
        }
    </style>
</head>

<body>
    <?php
        $opd = $pengajuan->organisasi?->opd;
        $logoPath = public_path('img/logo-only.png');
        $logoSrc = is_file($logoPath)
            ? 'data:image/png;base64,' . base64_encode((string) file_get_contents($logoPath))
            : '';
    ?>

    <table class="kop-table">
        <tr>
            <td class="kop-logo-cell">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($logoSrc)): ?>
                    <img class="kop-logo" src="<?php echo e($logoSrc); ?>" alt="Logo" />
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </td>
            <td class="kop-text-cell">
                <div class="kop-line1">PEMERINTAH KABUPATEN LOMBOK BARAT</div>
                <div class="kop-line2"><?php echo e($opd?->nama ?? ''); ?></div>
                <div class="kop-line3"><?php echo e($opd?->alamat ?? ''); ?></div>
                <div class="kop-line4">
                    Telp: <?php echo e($opd?->no_telp ?? '-'); ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($opd?->fax)): ?>
                        &nbsp;Faks: <?php echo e($opd?->fax); ?>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="kop-line5">
                    Email: <?php echo e($opd?->email ?? '-'); ?><?php echo e($opd?->website ? ' | Website: ' . $opd?->website : ''); ?>

                </div>
            </td>
        </tr>
    </table>

    <div class="kop-hr"></div>

    <div class="title" style="text-transform: capitalize;">
        Berita Acara Hasil Verifikasi Usulan Permohonan Belanja Barang
        Diserahkan Kepada Masyarakat Tahun Anggaran <?php echo e($tahunAnggaran); ?>

    </div>

    <div class="section">
        <div class="bold lvl-0">I. Evaluasi</div>

        <div class="row lvl-1 bold" style="margin-top: 6px;">A. Data Proposal</div>

        <div class="lvl-2">
            <table class="proposal-list">
                <tr>
                    <td class="num">1.</td>
                    <td class="lbl">Nama Kelompok</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e($namaKelompok); ?></td>
                </tr>
                <tr>
                    <td class="num">2.</td>
                    <td class="lbl">Alamat</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e($alamat ?: '-'); ?></td>
                </tr>
                <tr>
                    <td class="num">3.</td>
                    <td class="lbl">Ketua/Pengurus/Pemohon</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e($pemohon); ?></td>
                </tr>
                <tr>
                    <td class="num">4.</td>
                    <td class="lbl">Jenis Barang</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e($jenisBarang); ?></td>
                </tr>
                <tr>
                    <td class="num">5.</td>
                    <td class="lbl">Spesifikasi Teknis</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e($spesifikasiTeknis ?: '-'); ?></td>
                </tr>
                <tr>
                    <td class="num">6.</td>
                    <td class="lbl">Satuan</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e($satuan ?: '-'); ?></td>
                </tr>
                <tr>
                    <td class="num">7.</td>
                    <td class="lbl">Jumlah Usulan</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e(number_format((float) $jumlahUsulan, 0, ',', '.')); ?></td>
                </tr>
                <tr>
                    <td class="num">8.</td>
                    <td class="lbl">Jumlah Disetujui</td>
                    <td class="sep">:</td>
                    <td class="bold"><?php echo e(number_format((float) $jumlahDisetujui, 0, ',', '.')); ?></td>
                </tr>
            </table>
        </div>

        <div class="row lvl-1 bold" style="margin-top: 8px;">B. Pemeriksa</div>

        <div class="lvl-2">
            <?php ($pemeriksaKolom = max(\App\Models\PengajuanPemeriksa::MIN_VERIFIKASI_COUNT, $pemeriksa->count())); ?>
            <table class="table table-pemeriksa">
                <thead>
                    <tr>
                        <th class="pemeriksa-corner" scope="col"></th>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($n = 1; $n <= $pemeriksaKolom; $n++): ?>
                            <th class="pemeriksa-head" scope="col">Pemeriksa <?php echo e($n); ?></th>
                        <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="pemeriksa-label-col" style="width: 60px;">Nama</td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < $pemeriksaKolom; $i++): ?>
                            <td class="pemeriksa-value"><?php echo e($pemeriksa->get($i)?->nama ?? ''); ?></td>
                        <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tr>
                    <tr>
                        <td class="pemeriksa-label-col" style="width: 60px;">NIP</td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < $pemeriksaKolom; $i++): ?>
                            <td class="pemeriksa-value"><?php echo e($pemeriksa->get($i)?->nip ?? ''); ?></td>
                        <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tr>
                    <tr>
                        <td class="pemeriksa-label-col" style="width: 60px;">Jabatan</td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < $pemeriksaKolom; $i++): ?>
                            <td class="pemeriksa-value"><?php echo e($pemeriksa->get($i)?->jabatan ?? ''); ?></td>
                        <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tr>
                    <tr class="pemeriksa-paraf-row">
                        <td class="pemeriksa-label-col" style="width: 60px;">Paraf</td>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 0; $i < $pemeriksaKolom; $i++): ?>
                            <td class="pemeriksa-value pemeriksa-paraf-cell">&nbsp;</td>
                        <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="section">
        <?php ($tglVerifikasi = $pengajuan->verified_at->locale('id')); ?>
        <div class="lvl-1">Berdasarkan hasil verifikasi administrasi terhadap permohonan/proposal yang dilaksanakan
            pada hari <?php echo e($tglVerifikasi->translatedFormat('l')); ?> tanggal
            <?php echo e($tglVerifikasi->translatedFormat('d')); ?> bulan
            <?php echo e($tglVerifikasi->translatedFormat('F')); ?>

            tahun <?php echo e($tglVerifikasi->translatedFormat('Y')); ?>, dengan hasil sebagai berikut:
        </div>

        <div class="lvl-2">
            <table class="kriteria-list">
                <tr>
                    <td class="num">1.</td>
                    <td class="lbl bold">Memenuhi kriteria pemberian bantuan barang</td>
                    <td class="sep">:</td>
                    <td><?php echo e($verifikasi->lulus_kriteria ? 'Ya' : 'Tidak'); ?></td>
                </tr>
                <tr>
                    <td class="num">2.</td>
                    <td class="lbl bold">Kelengkapan administrasi penerima bantuan barang sesuai perbup</td>
                    <td class="sep">:</td>
                    <td><?php echo e($verifikasi->lulus_administrasi ? 'Lengkap' : 'Tidak Lengkap'); ?></td>
                </tr>
                <tr>
                    <td class="num">3.</td>
                    <td class="lbl bold">Kesesuaian kegiatan dengan proposal</td>
                    <td class="sep">:</td>
                    <td><?php echo e($verifikasi->lulus_kesesuaian ? 'Sesuai' : 'Tidak Sesuai'); ?></td>
                </tr>
                <tr>
                    <td class="num">4.</td>
                    <td class="lbl bold">Kegiatan tersebut menunjang pencapaian sasaran program dan kegiatan pemerintah
                        daerah</td>
                    <td class="sep">:</td>
                    <td><?php echo e($verifikasi->sesuai_program_pemda ? 'Ya' : 'Tidak'); ?></td>
                </tr>
                <tr>
                    <td class="num">5.</td>
                    <td class="lbl bold">Keterangan lainnya</td>
                    <td class="sep">:</td>
                    <td><?php echo e($verifikasi->catatan ?: '-'); ?></td>
                </tr>
            </table>
        </div>
    </div>

    <div class="section">
        <div class="bold lvl-0">II. Rekomendasi</div>
        <div class="row lvl-1" style="margin-top: 6px;">
            Berkenaan dengan hal tersebut, permohonan/proposal dinilai layak untuk diberikan belanja barang yang
            diserahkan kepada masyarakat berupa sebagaimana tercantum dalam tabel di atas dengan nilai sebesar Rp.
            <?php echo e($nilaiBesar); ?>

            (<?php echo e($nilaiBesarTerbilang); ?>).
        </div>
        <div class="row lvl-1" style="margin-top: 10px;">
            Demikian bagian rekomendasi hasil evaluasi ini dibuat untuk dapat dipergunakan sebagaimana mestinya.
        </div>
        <div class="ttd-wrap">
            <div class="ttd-inner">
                <div class="bold">Mengesahkan</div>
                <div class="ttd-date-line" style="margin-top: 4px; margin-bottom: 8px;">
                    <?php echo e($verifikasi->lokasi_pengesahan ?: 'Gerung'); ?>,
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->tgl_disahkan): ?>
                        <?php echo e($verifikasi->tgl_disahkan->translatedFormat('d F Y')); ?>

                    <?php else: ?>
                        .................. <?php echo e(now()->translatedFormat('Y')); ?>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="bold ttd-kepala-jabatan">Kepala SKPD,</div>
                <div class="ttd-ruang-tanda-tangan" aria-hidden="true"></div>
                <div class="bold ttd-kepala-nama"><?php echo e($verifikasi->disahkan_oleh ?: '-'); ?></div>
                <div class="ttd-kepala-garis">...................................................</div>
                <div class="ttd-kepala-nip">NIP: <?php echo e($verifikasi->disahkan_nip ?? ''); ?></div>
            </div>
        </div>
    </div>

    <div class="ba-doc-footer">
        Dokumen ini dicetak melalui aplikasi <span class="ba-doc-footer-app">Bantu In</span>
    </div>
</body>

</html>
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/verifikasi-pengajuan/ba-verifikasi.blade.php ENDPATH**/ ?>