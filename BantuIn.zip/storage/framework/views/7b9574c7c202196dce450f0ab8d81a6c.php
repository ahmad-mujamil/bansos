<!-- Favicon Tags Start -->
<link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.ico')); ?>" sizes="196x196" />
<meta name="application-name" content="memofit" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">

<!-- Favicon Tags End -->
<!-- Font Tags Start -->
<link rel="preconnect" href="https://fonts.gstatic.com" />
<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;700&display=swap" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('/font/CS-Interface/style.css')); ?>" />
<!-- Font Tags End -->
<!-- Vendor Styles Start -->
<link rel="stylesheet" href="<?php echo e(asset('/css/vendor/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/css/vendor/OverlayScrollbars.min.css')); ?>" />
<!-- Vendor Styles End -->

<!-- Livewire Styles -->
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


<!-- Template Base Styles Start -->
<link rel="stylesheet" href="<?php echo e(asset('/css/styles.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>" />
<!-- Template Base Styles End -->

<script src="<?php echo e(asset('/icon/acorn-icons.js')); ?>"></script>
<script src="<?php echo e(asset('/icon/acorn-icons-interface.js')); ?>"></script>
<script src="<?php echo e(asset('/icon/acorn-icons-commerce.js')); ?>"></script>
<script src="<?php echo e(asset('/icon/acorn-icons-medical.js')); ?>"></script>

<script src="<?php echo e(asset('/js/base/loader.js')); ?>"></script>
<?php echo $__env->yieldPushContent('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/css/vendor/select2-bansos-theme.css')); ?>" />
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/components/head.blade.php ENDPATH**/ ?>