<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Content Start -->
    <div class="col">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container mb-3">
            <div class="row">
                <!-- Title Start -->
                <div class="col mb-2">
                    <h4>Selamat Datang, <b><?php echo e(auth()->user()->nama??'-'); ?></b></h4>
                    <div class="text-muted font-heading text-small">Halaman Beranda</div>
                </div>
                <!-- Title End -->
            </div>
        </div>
        <!-- Title and Top Buttons End -->

        <!-- Stats Start -->
        <div class="mb-5">
            <h2 class="small-title">Summary</h2>
            <div class="row g-2">
                <div class="col-12 col-lg-3 col-xxl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="heading mb-0 d-flex justify-content-between lh-1-25 mb-3">
                                <span>Total <b>Organisasi/Kelompok</b></span>
                                <i data-acorn-icon="category" class="text-primary"></i>
                            </div>
                            
                            
                            
                            
                            <div class="cta-1 text-primary"><?php echo e(number_format($totalOrganisasi)); ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-3 col-xxl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="heading mb-0 d-flex justify-content-between lh-1-25 mb-3">
                                <span>Total <b>Pengajuan</b></span>
                                <i data-acorn-icon="category" class="text-primary"></i>
                            </div>
                            
                            
                            
                            
                            <div class="cta-1 text-primary"><?php echo e(number_format($totalPengajuan)); ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-3 col-xxl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="heading mb-0 d-flex justify-content-between lh-1-25 mb-3">
                                <span>Total <b>Realisasi</b></span>
                                <i data-acorn-icon="category" class="text-primary"></i>
                            </div>
                            
                            
                            
                            
                            <div class="cta-1 text-primary">Rp. <?php echo e(number_format($totalBansos)); ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-3 col-xxl-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="heading mb-0 d-flex justify-content-between lh-1-25 mb-3">
                                <span>Total <b>Blacklist</b></span>
                                <i data-acorn-icon="user" class="text-primary"></i>
                            </div>
                            <div class="cta-1 text-primary"><?php echo e(number_format($totalBlacklist)); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-5">
            <h2 class="small-title mb-3">Pilih Jenis Bantuan</h2>
            <p class="text-muted mb-4">Silakan pilih jenis bantuan yang ingin Anda ajukan. Klik kartu untuk melanjutkan.</p>
            <div class="row g-4">
                
                
                    <div class="col-4">
                        <a href="<?php echo e(route('pengajuan-opd.create', ['jenis' => 'bansos'])); ?>" class="text-decoration-none d-block h-100">
                            <div class="card border-0 shadow-sm h-100 overflow-hidden menu-bantuan-card" style="border-radius: 16px; transition: transform 0.25s ease, box-shadow 0.25s ease;">
                                <div class="card-body p-0 position-relative" style="background: linear-gradient(145deg, #ea580c 0%, #c2410c 50%, #9a3412 100%); min-height: 200px;">
                                    <div class="p-4 position-relative z-1">
                                        <div class="d-inline-flex align-items-center justify-content-center rounded-3 p-3 mb-3" style="width: 56px; height: 56px; background: rgba(255,255,255,0.25);">
                                            <i data-acorn-icon="heart" data-acorn-size="28" class="text-white"></i>
                                        </div>
                                        <h5 class="text-white fw-bold mb-2">Bantuan Sosial</h5>
                                        <p class="text-white mb-0 small opacity-90" style="font-size: 0.875rem; line-height: 1.5;">Bantuan sosial untuk meringankan beban dan mendukung kebutuhan dasar penerima manfaat.</p>
                                        <span class="d-inline-flex align-items-center mt-3 text-white fw-semibold" style="font-size: 0.9rem;">
                                            Ajukan sekarang
                                            <i data-acorn-icon="chevron-right" data-acorn-size="18" class="ms-1"></i>
                                        </span>
                                    </div>
                                    <div class="position-absolute bottom-0 end-0 opacity-10" style="font-size: 6rem; line-height: 1;">
                                        <i data-acorn-icon="heart" class="text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                
                
                    <div class="col-4">
                        <a href="<?php echo e(route('pengajuan-opd.create', ['jenis' => 'bantuan_kelompok'])); ?>" class="text-decoration-none d-block h-100">
                            <div class="card border-0 shadow-sm h-100 overflow-hidden menu-bantuan-card" style="border-radius: 16px; transition: transform 0.25s ease, box-shadow 0.25s ease;">
                                <div class="card-body p-0 position-relative" style="background: linear-gradient(145deg, #0d9488 0%, #0f766e 50%, #115e59 100%); min-height: 200px;">
                                    <div class="p-4 position-relative z-1">
                                        <div class="d-inline-flex align-items-center justify-content-center rounded-3 p-3 mb-3" style="width: 56px; height: 56px; background: rgba(255,255,255,0.25);">
                                            <i data-acorn-icon="grid-1" data-acorn-size="28" class="text-white"></i>
                                        </div>
                                        <h5 class="text-white fw-bold mb-2">Bantuan ke Masyarakat</h5>
                                        <p class="text-white mb-0 small opacity-90" style="font-size: 0.875rem; line-height: 1.5;">Bantuan untuk program pemberdayaan dan peningkatan kesejahteraan kelompok masyarakat.</p>
                                        <span class="d-inline-flex align-items-center mt-3 text-white fw-semibold" style="font-size: 0.9rem;">
                                            Ajukan sekarang
                                            <i data-acorn-icon="chevron-right" data-acorn-size="18" class="ms-1"></i>
                                        </span>
                                    </div>
                                    <div class="position-absolute bottom-0 end-0 opacity-10" style="font-size: 6rem; line-height: 1;">
                                        <i data-acorn-icon="grid-1" class="text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                
                
                    <div class="col-4">
                        <a href="<?php echo e(route('pengajuan-opd.create', ['jenis' => 'hibah'])); ?>" class="text-decoration-none d-block h-100">
                            <div class="card border-0 shadow-sm h-100 overflow-hidden menu-bantuan-card" style="border-radius: 16px; transition: transform 0.25s ease, box-shadow 0.25s ease;">
                                <div class="card-body p-0 position-relative" style="background: linear-gradient(145deg, #6366f1 0%, #4f46e5 50%, #4338ca 100%); min-height: 200px;">
                                    <div class="p-4 position-relative z-1">
                                        <div class="d-inline-flex align-items-center justify-content-center rounded-3 p-3 mb-3" style="width: 56px; height: 56px; background: rgba(255,255,255,0.25);">
                                            <i data-acorn-icon="gift" data-acorn-size="28" class="text-white"></i>
                                        </div>
                                        <h5 class="text-white fw-bold mb-2">Hibah</h5>
                                        <p class="text-white mb-0 small opacity-90" style="font-size: 0.875rem; line-height: 1.5;">Bantuan hibah untuk mendukung kegiatan atau program yang Anda jalankan.</p>
                                        <span class="d-inline-flex align-items-center mt-3 text-white fw-semibold" style="font-size: 0.9rem;">
                                            Ajukan sekarang
                                            <i data-acorn-icon="chevron-right" data-acorn-size="18" class="ms-1"></i>
                                        </span>
                                    </div>
                                    <div class="position-absolute bottom-0 end-0 opacity-10" style="font-size: 6rem; line-height: 1;">
                                        <i data-acorn-icon="gift" class="text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pendudukTidakValid->isNotEmpty()): ?>
            <div class="mb-5">
                <h2 class="small-title mb-3">Penduduk Tidak Valid</h2>
                <p class="text-muted mb-3">
                    Penduduk yang terdaftar pada kelompok di OPD Anda dengan status verifikasi
                    <span class="badge bg-danger">Tidak Valid</span>.
                </p>

                <div class="card mb-5">
                    <div class="card-body">
                        <table class="data-table data-table-pagination data-table-standard responsive nowrap stripe" id="datatable-tidak-valid">
                            <thead>
                                <tr>
                                    <th class="text-muted text-small text-uppercase">Nama</th>
                                    <th class="text-muted text-small text-uppercase">NIK</th>
                                    <th class="text-muted text-small text-uppercase">Kelompok</th>
                                    <th class="text-muted text-small text-uppercase">Catatan</th>
                                    <th class="text-muted text-small text-uppercase">Diverifikasi</th>
                                </tr>
                            </thead>
                            <tbody class="text-alternate text-medium">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pendudukTidakValid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $kelompokItems = $p->organisasiDetails
                                        ->filter(fn ($d) => $d->organisasi !== null)
                                        ->map(fn ($d) => [
                                            'nama' => $d->organisasi->nama,
                                            'jabatan' => $d->jabatan?->getDescription() ?? null,
                                        ])
                                        ->unique('nama')
                                        ->values();
                                    $catatan = trim((string) $p->catatan_validasi) !== ''
                                        ? $p->catatan_validasi
                                        : '-';
                                ?>
                                <tr>
                                    <td><?php echo e($p->nama); ?></td>
                                    <td><?php echo e($p->nik); ?></td>
                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $kelompokItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="mb-1">
                                                <span class="badge bg-primary"><?php echo e($k['nama']); ?></span>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($k['jabatan']): ?>
                                                    <small class="text-muted ms-1"><?php echo e($k['jabatan']); ?></small>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td><?php echo e($catatan); ?></td>
                                    <td>
                                        <?php echo e($p->validated_at?->translatedFormat('d M Y H:i')); ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($p->validatedBy): ?>
                                            <div class="text-muted text-small">oleh <?php echo e($p->validatedBy->nama); ?></div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <!-- Stats End -->

        <!-- Charts Start -->
























        <!-- Charts End -->
    </div>
    <!-- Page Content End -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/css/vendor/datatables.min.css')); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js_vendor'); ?>
    <script src="<?php echo e(asset('js/cs/datatable.extend.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/datatables.min.js')); ?>"></script>
    <script>
        $(function () {
            new DatatableExtend();
            if ($('#datatable-tidak-valid').length) {
                $('#datatable-tidak-valid').DataTable({
                    language: {
                        paginate: {
                            previous: '<i class="cs-chevron-left"></i>',
                            next: '<i class="cs-chevron-right"></i>',
                        },
                    },
                    responsive: true,
                    lengthChange: true,
                    lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'Semua']],
                    pageLength: 10,
                    sDom: '<"row"<"col-sm-12"<"table-container"t>r>><"row align-items-center mt-3"<"col-sm-6"l><"col-sm-6"p>>',
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js_page'); ?>







































































































<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/home-opd.blade.php ENDPATH**/ ?>