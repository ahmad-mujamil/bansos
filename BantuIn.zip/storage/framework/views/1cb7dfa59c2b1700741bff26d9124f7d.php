<?php $__env->startSection('title', 'Security'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Content Start -->
    <div class="col">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container mb-3">
            <div class="row">
                <!-- Title Start -->
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4" id="title">Security</h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">Security</a></li>
                        </ul>
                    </nav>
                </div>
                <!-- Title End -->
            </div>
        </div>
        <!-- Title and Top Buttons End -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <!-- Public Info Start -->
        <h2 class="small-title">Update Password</h2>
        <div class="card mb-5">
            <div class="card-body">
                <form novalidate enctype="multipart/form-data" action="<?php echo e(route('password.update')); ?>" method="POST" class="needs-validation">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3 row">
                        <label class="col-lg-2 col-md-3 col-sm-4 col-form-label">Password Lama</label>
                        <div class="col-sm-8 col-md-9 col-lg-10">
                            <div class="position-relative">
                                <input type="password" class="form-control password-input" value="" name="password_old" id="password_old" required />
                                <button class="btn position-absolute end-0 top-0 h-100 px-3 password-addon" type="button">
                                    <i data-acorn-icon="eye-off" class="icon-eye-off text-primary"></i>
                                    <i data-acorn-icon="eye" class="icon-eye d-none text-primary"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-lg-2 col-md-3 col-sm-4 col-form-label">Password Baru</label>
                        <div class="col-sm-8 col-md-9 col-lg-10">
                            <div class="position-relative">
                                <input type="password" class="form-control password-input" value="" name="password" id="password" required />
                                <button class="btn position-absolute end-0 top-0 h-100 px-3 password-addon" type="button">
                                    <i data-acorn-icon="eye-off" class="icon-eye-off text-primary"></i>
                                    <i data-acorn-icon="eye" class="icon-eye d-none text-primary"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-lg-2 col-md-3 col-sm-4 col-form-label">Konfirmasi Password</label>
                        <div class="col-sm-8 col-md-9 col-lg-10">
                            <div class="position-relative">
                                <input type="password" class="form-control password-input" name="password_confirmation" id="password_confirmation" required />
                                <button class="btn position-absolute end-0 top-0 h-100 px-3 password-addon" type="button">
                                    <i data-acorn-icon="eye-off" class="icon-eye-off text-primary"></i>
                                    <i data-acorn-icon="eye" class="icon-eye d-none text-primary"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 row mt-5">
                        <div class="col-sm-8 col-md-9 col-lg-10 ms-auto">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- Public Info End -->
    </div>
    <!-- Page Content End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.form_validation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/security.blade.php ENDPATH**/ ?>