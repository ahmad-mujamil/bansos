<?php $__env->startSection('title', $berita->judul); ?>

<?php $__env->startSection('content'); ?>
    <article>
        <nav class="text-sm text-on-surface-variant mb-6">
            <a href="<?php echo e(route('landing')); ?>" class="hover:text-primary">Home</a>
            <span class="mx-2">/</span>
            <a href="<?php echo e(route('berita.publik.index')); ?>" class="hover:text-primary">Berita</a>
            <span class="mx-2">/</span>
            <span class="text-on-surface"><?php echo e(\Illuminate\Support\Str::limit($berita->judul, 48)); ?></span>
        </nav>

        <header class="mb-8">
            <span class="text-xs font-bold text-primary-container tracking-widest uppercase"><?php echo e($berita->kategoriBerita?->nama ?? '—'); ?></span>
            <h1 class="text-3xl md:text-4xl font-bold text-primary mt-2 leading-tight"><?php echo e($berita->judul); ?></h1>
            <p class="text-on-surface-variant mt-4 text-lg"><?php echo e($berita->ringkasan); ?></p>
            <div class="flex items-center gap-4 mt-4 text-sm text-slate-500">
                <span class="inline-flex items-center gap-1">
                    <span class="material-symbols-outlined text-base">calendar_today</span>
                    <?php echo e($berita->published_at?->translatedFormat('d F Y')); ?>

                </span>
            </div>
        </header>

        <?php $hero = $berita->getFirstMediaUrl('featured'); ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($hero !== ''): ?>
            <figure class="mb-10 rounded-2xl overflow-hidden">
                <img src="<?php echo e($hero); ?>" alt="<?php echo e($berita->judul); ?>" class="w-full max-h-[480px] object-cover"/>
            </figure>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="max-w-none text-on-surface leading-relaxed text-base [&_p]:mb-4 [&_ul]:list-disc [&_ul]:ps-6 [&_ol]:list-decimal [&_ol]:ps-6">
            <?php echo $berita->konten; ?>

        </div>

        <div class="mt-12 pt-8 border-t border-outline-variant">
            <a href="<?php echo e(route('berita.publik.index')); ?>" class="inline-flex items-center gap-2 font-semibold text-primary hover:underline">
                <span class="material-symbols-outlined">arrow_back</span> Semua berita
            </a>
        </div>
    </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public-bantuin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/berita/publik-show.blade.php ENDPATH**/ ?>