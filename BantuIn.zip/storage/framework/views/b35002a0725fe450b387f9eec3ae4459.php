<?php $__env->startSection('title', 'Detail Pengajuan OPD'); ?>
<?php $__env->startSection('content'); ?>
<div class="col">
    <div class="page-title-container mb-3">
        <div class="row">
            <div class="col mb-2">
                <h1 class="mb-2 pb-0 display-4">Detail Pengajuan OPD</h1>
            </div>
            <div class="col-12 col-md-6 d-flex justify-content-end gap-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->canEdit()): ?>
                    <a href="<?php echo e(route('pengajuan-opd.edit', $pengajuan)); ?>" class="btn btn-outline-primary">Edit</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->canSubmit()): ?>
                    <form action="<?php echo e(route('pengajuan-opd.submit', $pengajuan)); ?>" method="POST" class="form-ajukan-pengajuan">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success">Ajukan</button>
                    </form>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <a href="<?php echo e(route('pengajuan-opd.index')); ?>" class="btn btn-outline-secondary">Kembali</a>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="text-muted small">Kode</div>
                    <div class="fw-semibold"><?php echo e($pengajuan->kode_pengajuan); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="text-muted small">Status</div>
                    <div><span class="badge bg-<?php echo e($pengajuan->status?->badgeColor() ?? 'secondary'); ?>"><?php echo e($pengajuan->status->getDescription()); ?></span></div>
                </div>
                <div class="col-md-6">
                    <div class="text-muted small">Jenis penerima bantuan</div>
                    <div class="fw-semibold"><?php echo e($pengajuan->jenis_penerima_bantuan?->getDescription() ?? '-'); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="text-muted small">Kelompok</div>
                    <div class="fw-semibold"><?php echo e($pengajuan->organisasi?->nama ?? '-'); ?></div>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->details->isNotEmpty() && $pengajuan->details->first()?->penduduk): ?>
                <div class="col-md-6">
                    <div class="text-muted small">Penduduk (rincian)</div>
                    <div class="fw-semibold">
                        <?php echo e($pengajuan->details->first()->penduduk->nama); ?>

                        <span class="text-muted">— NIK <?php echo e($pengajuan->details->first()->penduduk->nik); ?></span>
                    </div>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="col-md-6">
                    <div class="text-muted small">Nilai</div>
                    <div class="fw-semibold">Rp <?php echo e(number_format($pengajuan->nilai, 0, ',', '.')); ?></div>
                </div>
                <div class="col-12">
                    <div class="text-muted small">Judul</div>
                    <div class="fw-semibold"><?php echo e($pengajuan->judul); ?></div>
                </div>
                <div class="col-12">
                    <div class="text-muted small">Lokasi</div>
                    <div><?php echo e($pengajuan->lokasi ?? '-'); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="text-muted small">Desa</div>
                    <div><?php echo e($pengajuan->desa?->nama ?? '-'); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="text-muted small">Kecamatan</div>
                    <div><?php echo e($pengajuan->desa?->kecamatan?->nama ?? '-'); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_vendor'); ?>
<script src="<?php echo e($cdn ?? asset('vendor/sweetalert/sweetalert.all.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_page'); ?>
<script>
    document.querySelectorAll('form.form-ajukan-pengajuan').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var f = this;
            Swal.fire({
                title: 'Ajukan Pengajuan',
                text: 'Apakah Anda yakin ingin mengajukan pengajuan ini?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, ajukan',
                cancelButtonText: 'Batal'
            }).then(function(result) {
                if (result.isConfirmed) f.submit();
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/pengajuan-opd/show.blade.php ENDPATH**/ ?>