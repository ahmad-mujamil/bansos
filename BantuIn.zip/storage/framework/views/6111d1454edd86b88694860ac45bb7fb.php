<!-- Vendor Scripts Start -->
<script src="<?php echo e(asset('/js/vendor/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/OverlayScrollbars.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/autoComplete.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/vendor/clamp.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('js_vendor'); ?>
<!-- Vendor Scripts End -->

<!-- Livewire Scripts -->

<!-- Template Base Scripts Start -->
<script src="<?php echo e(asset('/js/base/helpers.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/globals.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/nav.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/search.js')); ?>"></script>
<script src="<?php echo e(asset('/js/base/settings.js')); ?>"></script>
<!-- Template Base Scripts End -->
<!-- Page Specific Scripts Start -->
<script src="<?php echo e(asset('/js/common.js')); ?>"></script>
<script src="<?php echo e(asset('/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('/js/password-addon.init.js')); ?>"></script>
<?php echo $__env->yieldPushContent('js_page'); ?>
<!-- Page Specific Scripts End -->
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/components/scripts.blade.php ENDPATH**/ ?>