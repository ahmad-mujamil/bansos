<?php $__env->startSection('title', 'Pengguna'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Content Start -->
    <div class="col">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container mb-3">
            <div class="row">
                <!-- Title Start -->
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4" id="title">Pengguna</h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">Master Data</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('pengguna.index')); ?>">Pengguna</a></li>
                            <li class="breadcrumb-item"><a
                                    href="javascript:;"><?php echo e(request()->routeIs('pengguna.create') ? 'Tambah Data' : 'Edit Data'); ?></a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <!-- Title End -->
                <!-- Top Buttons Start -->
                <div class="col-12 col-md-5 d-flex align-items-start justify-content-end">
                    <!-- Back Button Start -->
                    <a href="<?php echo e(route('pengguna.index')); ?>"
                       class="btn btn-outline-primary btn-icon btn-icon-start w-100 w-md-auto">
                        <i data-acorn-icon="arrow-left"></i>
                        <span>Kembali</span>
                    </a>
                    <!-- Back Button End -->
                </div>
                <!-- Top Buttons End -->
            </div>
        </div>
        <!-- Title and Top Buttons End -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="card mb-5">
            <?php
                $route = request()->routeIs('pengguna.create') ? route('pengguna.store') : route('pengguna.update',$pengguna->id??'');
                $method = request()->routeIs('pengguna.create') ? 'POST' : 'PUT';
            ?>
            <form novalidate enctype="multipart/form-data" action="<?php echo e($route); ?>" method="POST" class="needs-validation">
                <?php echo csrf_field(); ?>
                <?php echo method_field($method); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-sm-12 mb-3">
                            <label class="form-label text-small text-uppercase">Nama Pengguna</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama"
                                   name="nama" required
                                   value="<?php echo e(old('nama',$pengguna->nama??'')); ?>"/>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 mb-3">
                            <label class="form-label text-small text-uppercase">Email</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                                   name="email" required
                                   value="<?php echo e(old('email',$pengguna->email??'')); ?>"/>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 mb-3">
                            <label class="form-label text-small text-uppercase">Role</label>
                            <select name="role" id="role" class="form-control <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Pilih Role</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = \App\Enums\RoleUser::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($item->value); ?>" <?php echo e((old('role',$pengguna->role?->value??'') == $item->value) ? 'selected' : ''); ?>>
                                        <?php echo e($item->getDescription()); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 mb-3">
                            <label class="form-label text-small text-uppercase">Username</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="username" name="username" required
                                   value="<?php echo e(old('username',$pengguna->username??'')); ?>"/>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 mb-3">
                            <label class="form-label text-small text-uppercase">Password</label>
                            <div class="position-relative">
                                <input type="password" class="form-control password-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="password" name="password" <?php echo e(request()->routeIs('pengguna.create') ? 'required' : ''); ?>

                                       />
                                <button class="btn position-absolute end-0 top-0 h-100 px-3 password-addon" type="button">
                                    <i data-acorn-icon="eye-off" class="icon-eye-off text-primary"></i>
                                    <i data-acorn-icon="eye" class="icon-eye d-none text-primary"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="col-lg-3 col-md-3 col-sm-12 mb-3">
                            <label class="form-label text-small text-uppercase">Status</label>
                            <select name="is_active" id="is_active"
                                    class="form-control <?php $__errorArgs = ['is_active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Pilih Status</option>
                                <option
                                    value="1" <?php echo e((old('is_active',$pengguna->is_active??'') == 1) ? 'selected' : ''); ?>>
                                    Active
                                </option>
                                <option
                                    value="0" <?php echo e((old('is_active',$pengguna->is_active??'') == 0) ? 'selected' : ''); ?>>
                                    Non Active
                                </option>
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 mb-3">
                            <label class="form-label text-small text-uppercase">OPD</label>
                            <select name="opd_id" id="opd_id" class="form-control <?php $__errorArgs = ['opd_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Pilih OPD</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $opds ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($opd->id); ?>" <?php echo e((old('opd_id',$pengguna->opd_id??'') == $opd->id) ? 'selected' : ''); ?>>
                                        <?php echo e($opd->nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mt-3">Simpan Data</button>
                </div>
            </form>
        </div>
        <!-- Content Start -->
    </div>
    <!-- Page Content End -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js_vendor'); ?>
    <script src="<?php echo e(asset('js/vendor/select2.full.min.js')); ?>"></script>
    <script>
        $("document").ready(function () {
            $('#role').select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih Role',
                allowClear: true,
            });
            $('#is_active').select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih Status',
                allowClear: true,
            });
            $('#opd_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih OPD',
                allowClear: true,
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('components.form_validation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/pengguna/create.blade.php ENDPATH**/ ?>