<!-- Menu Start -->
<div class="col-auto d-none d-lg-flex" style="max-height: 100vh; overflow-y: auto;">
    <ul class="sw-25 side-menu mb-0 primary" id="menuSide">
        <li>
            <ul>
                <li>
                    <a href="#" data-bs-target="#getting_started">
                        <i data-acorn-icon="grid-1" class="icon" data-acorn-size="18"></i>
                        <span class="label">Getting Started</span>
                    </a>
                    <ul id="getting_started">
                        <li class="<?php echo e(request()->routeIs('home') ? 'ps-2 bg-primary rounded' : ''); ?>">
                            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active fw-bold' : ''); ?>">
                                <i data-acorn-icon="grid-1" class="icon <?php echo e(request()->routeIs('home') ? 'text-white' : ''); ?>" data-acorn-size="18"></i>
                                <span class="label <?php echo e(request()->routeIs('home') ? 'text-white' : ''); ?>">Dashboard</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php
                    $currentUrl = Request::path();
                    $sidebarMenus = collect(config('sidebar'));
                    $userMenus = auth()->user()->role->getPermissions();
                    $canAccessSidebarMenus = !auth()->user()->is_user() || auth()->user()->is_active;
                ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canAccessSidebarMenus): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $sidebarMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($menu["id"], $userMenus) || auth()->user()->is_super()): ?>

                        <?php
                            $subMenus = collect($menu['sub_menu']);
                        ?>
                        <li>
                            <a href="#" data-bs-target="#sidebar_menu_<?php echo e($menu['id']); ?>">
                                <i data-acorn-icon="<?php echo e($menu['icon'] ?? 'map-1'); ?>" class="icon" data-acorn-size="18"></i>
                                <span class="label"><?php echo e($menu["title"]); ?></span>
                            </a>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($subMenus->count() > 0): ?>
                                <ul id="sidebar_menu_<?php echo e($menu['id']); ?>">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $subMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(in_array($subMenu["id"], $userMenus) || auth()->user()->is_super()): ?>
                                        <?php
                                            $isActive = str_contains("/".request()->path(), $subMenu['url']) || str_contains($currentUrl, $subMenu['url']);
                                        ?>
                                        <li class="<?php echo e($isActive ? 'ps-2 bg-primary rounded' : ''); ?>">
                                            <a href="<?php echo e($subMenu['url']); ?>" class="<?php echo e($isActive ? 'active fw-bold' : ''); ?>">
                                                <?php $icon = $subMenu['icon'] ?? 'database' ?>
                                                <i data-acorn-icon="<?php echo e($icon); ?>" class="icon d-none <?php echo e($isActive?'text-white':''); ?>" data-acorn-size="18"></i>
                                                <span class="label <?php echo e($isActive ? 'text-white' : ''); ?>"><?php echo e($subMenu["title"]); ?></span>
                                            </a>
                                        </li>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </ul>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </li>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </li>
    </ul>

</div>
<!-- Menu End -->
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/components/nav_secondary.blade.php ENDPATH**/ ?>