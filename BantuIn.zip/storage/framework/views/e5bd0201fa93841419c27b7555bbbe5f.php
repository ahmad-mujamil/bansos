<?php $__env->startSection('title', 'Detail Verifikasi Penduduk'); ?>
<?php $__env->startSection('content'); ?>
<div class="col">
    <!-- Page Title Start -->
    <div class="page-title-container mb-3">
        <div class="row">
            <div class="col mb-2">
                <h1 class="mb-2 pb-0 display-4">Detail Verifikasi Penduduk</h1>
                <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                    <ul class="breadcrumb pt-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="javascript:;">Verifikasi</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('verifikasi-penduduk.index')); ?>">Penduduk</a></li>
                        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e($penduduk->nik); ?></a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-12 col-md-5 d-flex align-items-start justify-content-end gap-2">
                <a href="<?php echo e(route('verifikasi-penduduk.index')); ?>"
                    class="btn btn-outline-secondary btn-icon btn-icon-start w-100 w-md-auto">
                    <i data-acorn-icon="arrow-left"></i>
                    <span>Kembali</span>
                </a>
            </div>
        </div>
    </div>
    <!-- Page Title End -->

    <div class="row">
        <div class="col-lg-6">
        <!-- Info Penduduk Start -->
        <div class="card mb-4">
            <div class="card-body">
                <h2 class="small-title mb-4">Informasi Penduduk</h2>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">NIK</span>
                        <div class="fw-semibold"><?php echo e($penduduk->nik); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Nama Lengkap</span>
                        <div class="fw-semibold"><?php echo e($penduduk->nama); ?></div>
                    </div>

                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Agama</span>
                        <div class="fw-semibold"><?php echo e($penduduk->agama); ?></div>
                    </div>
                    <div class="col-md-12 mb-3">
                        <span class="text-small text-uppercase text-muted">Alamat</span>
                        <div><?php echo e($penduduk->alamat?? '-'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Jenis Kelamin</span>
                        <div><?php echo e($penduduk->jk?->getDescription() ?? '-'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Tanggal Lahir</span>
                        <div><?php echo e($penduduk->tgl_lahir?->translatedFormat('d F Y') ?? '-'); ?></div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <span class="text-small text-uppercase text-muted">Pekerjaan</span>
                        <div class="fw-semibold"><?php echo e($penduduk->pekerjaan); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Desa</span>
                        <div><?php echo e($penduduk->desa?->nama ?? '-'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Kecamatan</span>
                        <div><?php echo e($penduduk->desa?->kecamatan?->nama ?? '-'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Status Validasi</span>
                        <div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($penduduk->is_valid): ?>
                                <span class="badge bg-success">Terverifikasi</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Belum Diverifikasi</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($penduduk->validated_at): ?>
                        <div class="col-md-4 mb-3">
                            <span class="text-small text-uppercase text-muted">Tanggal Diverifikasi</span>
                            <div><?php echo e($penduduk->validated_at->translatedFormat('d F Y H:i')); ?></div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <span class="text-small text-uppercase text-muted">Diverifikasi Oleh</span>
                            <div><?php echo e($penduduk->validatedBy?->nama ?? $penduduk->validatedBy?->email ?? '-'); ?></div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($penduduk->catatan_validasi): ?>
                        <div class="col-12 mb-3">
                            <span class="text-small text-uppercase text-muted">Catatan Validasi Sebelumnya</span>
                            <div class="p-3 bg-light rounded mt-1"><?php echo e($penduduk->catatan_validasi); ?></div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Info Penduduk End -->
        </div>
        <div class="col-lg-6">
        <!-- Form Verifikasi Start -->
        <div class="card mb-5">
            <div class="card-body">
                <h2 class="small-title mb-4">Form Verifikasi</h2>
                <form action="<?php echo e(route('verifikasi-penduduk.verifikasi', $penduduk->id)); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>

                    <div class="mb-4">
                        <label class="form-label text-small text-uppercase fw-semibold">Keputusan Verifikasi <span class="text-danger">*</span></label>
                        <div class="d-flex gap-4 mt-2">
                            <div class="form-check">
                                <input
                                    class="form-check-input <?php $__errorArgs = ['is_valid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="radio"
                                    name="is_valid"
                                    id="valid_yes"
                                    value="1"
                                    <?php echo e(old('is_valid', $penduduk->is_valid ? '1' : '') == '1' ? 'checked' : ''); ?>

                                    required
                                >
                                <label class="form-check-label text-success fw-semibold" for="valid_yes">
                                    <i data-acorn-icon="check-circle" class="me-1"></i> Valid / Terverifikasi
                                </label>
                            </div>
                            <div class="form-check">
                                <input
                                    class="form-check-input <?php $__errorArgs = ['is_valid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="radio"
                                    name="is_valid"
                                    id="valid_no"
                                    value="0"
                                    <?php echo e(old('is_valid', !$penduduk->is_valid && $penduduk->validated_at ? '0' : '') == '0' ? 'checked' : ''); ?>

                                    required
                                >
                                <label class="form-check-label text-danger fw-semibold" for="valid_no">
                                    <i data-acorn-icon="close-circle" class="me-1"></i> Tidak Valid
                                </label>
                            </div>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['is_valid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="mb-4">
                        <label for="catatan_validasi" class="form-label text-small text-uppercase fw-semibold">Catatan Validasi</label>
                        <textarea
                            class="form-control <?php $__errorArgs = ['catatan_validasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="catatan_validasi"
                            name="catatan_validasi"
                            rows="4"
                            maxlength="500"
                            placeholder="Tambahkan catatan verifikasi (opsional)..."
                        ><?php echo e(old('catatan_validasi', $penduduk->catatan_validasi)); ?></textarea>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['catatan_validasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div class="form-text">Maksimal 500 karakter.</div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary btn-icon btn-icon-start">
                            <i data-acorn-icon="check"></i>
                            <span>Simpan Verifikasi</span>
                        </button>
                        <a href="<?php echo e(route('verifikasi-penduduk.index')); ?>" class="btn btn-outline-secondary">
                            Batal
                        </a>
                    </div>
                </form>
            </div>
        </div>
        <!-- Form Verifikasi End -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/verifikasi-penduduk/show.blade.php ENDPATH**/ ?>