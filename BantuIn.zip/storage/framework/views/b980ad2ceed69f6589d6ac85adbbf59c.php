<?php $__env->startSection('title', $heroSlide ? 'Edit Slide' : 'Tambah Slide'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col">
        <div class="page-title-container mb-3">
            <div class="row">
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4" id="title"><?php echo e($heroSlide ? 'Edit Slide' : 'Tambah Slide'); ?></h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">Landing Page</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('kelola.slider.index')); ?>">Slider</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;"><?php echo e($heroSlide ? 'Edit' : 'Tambah'); ?></a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-12 col-md-5 d-flex align-items-start justify-content-end">
                    <a href="<?php echo e(route('kelola.slider.index')); ?>" class="btn btn-outline-primary btn-icon btn-icon-start w-100 w-md-auto">
                        <i data-acorn-icon="arrow-left"></i>
                        <span>Kembali</span>
                    </a>
                </div>
            </div>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="card mb-5">
            <?php
                $isEdit = (bool) $heroSlide;
                $route = $isEdit ? route('kelola.slider.update', $heroSlide) : route('kelola.slider.store');
                $method = $isEdit ? 'PUT' : 'POST';
            ?>
            <form novalidate enctype="multipart/form-data" action="<?php echo e($route); ?>" method="POST" class="needs-validation">
                <?php echo csrf_field(); ?>
                <?php echo method_field($method); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-small text-uppercase">Kategori (badge)</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kategori"
                                   value="<?php echo e(old('kategori', $heroSlide->kategori ?? '')); ?>" required maxlength="120"
                                   placeholder="Contoh: Program Pemerintah Resmi"/>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label text-small text-uppercase">Urutan</label>
                            <input type="number" min="0" max="65535" class="form-control <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="urutan"
                                   value="<?php echo e(old('urutan', $heroSlide->urutan ?? 0)); ?>"/>
                        </div>
                        <div class="col-md-3 mb-3 d-flex align-items-end">
                            <div class="form-check mb-0">
                                <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active"
                                    <?php echo e(old('is_active', $heroSlide === null || $heroSlide->is_active ? '1' : '') ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="is_active">Tampil di beranda</label>
                            </div>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label text-small text-uppercase">Judul utama</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="judul"
                                   value="<?php echo e(old('judul', $heroSlide->judul ?? '')); ?>" required maxlength="255"
                                   placeholder="Contoh: Gotong Royong Membangun"/>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label text-small text-uppercase">Judul sorot (warna aksen, opsional)</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['judul_sorot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="judul_sorot"
                                   value="<?php echo e(old('judul_sorot', $heroSlide->judul_sorot ?? '')); ?>" maxlength="255"
                                   placeholder="Contoh: Kesejahteraan."/>
                            <small class="text-muted">Kosongkan jika seluruh judul memakai warna sama.</small>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label text-small text-uppercase">Subtitle</label>
                            <textarea class="form-control <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="subtitle" rows="3" required maxlength="1000"><?php echo e(old('subtitle', $heroSlide->subtitle ?? '')); ?></textarea>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label text-small text-uppercase">Gambar hero</label>
                            <input type="file" class="form-control <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gambar" accept="image/jpeg,image/png,image/webp,image/gif" <?php echo e($isEdit ? '' : 'required'); ?>/>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEdit && $heroSlide->getFirstMediaUrl('hero')): ?>
                                <div class="mt-2">
                                    <span class="text-small text-muted d-block mb-1">Gambar saat ini:</span>
                                    <img src="<?php echo e($heroSlide->getFirstMediaUrl('hero')); ?>" alt="" class="rounded border" style="max-height:120px"/>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-2">Simpan</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.form_validation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/kelola/hero-slide/form.blade.php ENDPATH**/ ?>