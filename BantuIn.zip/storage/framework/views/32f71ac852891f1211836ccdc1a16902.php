<?php $__env->startSection('title', 'Detail BAST'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container mb-3">
            <div class="row">
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4">Detail BA Serah Terima</h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">BA Serah Terima</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('bast.index')); ?>">BAST</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;"><?php echo e($bast->nomor); ?></a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-12 col-md-5 d-flex align-items-start justify-content-end gap-1">
                    <a href="<?php echo e(route('bast.edit', $bast)); ?>" class="btn btn-outline-primary btn-icon btn-icon-start">
                        <i data-acorn-icon="edit"></i>
                        <span>Edit</span>
                    </a>
                    <a href="<?php echo e(route('bast.index')); ?>" class="btn btn-outline-secondary btn-icon btn-icon-start">
                        <i data-acorn-icon="arrow-left"></i>
                        <span>Kembali</span>
                    </a>
                </div>
            </div>
        </div>
        <!-- Title and Top Buttons End -->

        
        <div class="card mb-3">
            <div class="card-body py-3">
                <h2 class="small-title mb-3">Informasi BAST</h2>
                <div class="row g-2">
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Nomor BAST</p>
                        <p class="fw-semibold mb-0"><?php echo e($bast->nomor); ?></p>
                    </div>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Tanggal</p>
                        <p class="mb-0"><?php echo e($bast->tanggal?->translatedFormat('d F Y')); ?></p>
                    </div>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Penerima</p>
                        <p class="mb-0"><?php echo e($bast->penerima); ?></p>
                    </div>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Dibuat Oleh</p>
                        <p class="mb-0"><?php echo e($bast->user?->nama ?? $bast->user?->email ?? '-'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        
        <?php
            $pengajuan    = $bast->pengajuan;
            $verifikasi   = $pengajuan?->verifikasiPengajuan;
            $statusBadge = $pengajuan?->status?->badgeColor() ?? 'secondary';
        ?>

        <div class="row mb-3">
            <div class="col-lg-6 mb-3 mb-lg-0">
                <div class="card h-100">
                    <div class="card-body py-3">
                        <h2 class="small-title mb-3">Detail Pengajuan</h2>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan): ?>
                            <div class="row g-2">
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Kode</p>
                                    <p class="fw-semibold mb-0"><?php echo e($pengajuan->kode_pengajuan); ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Status</p>
                                    <p class="mb-0">
                                        <span class="badge bg-<?php echo e($statusBadge); ?>"><?php echo e($pengajuan->status->getDescription()); ?></span>
                                    </p>
                                </div>
                                <div class="col-12">
                                    <p class="text-small text-uppercase text-muted mb-1">Judul</p>
                                    <p class="mb-0"><?php echo e($pengajuan->judul); ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Jenis Bantuan</p>
                                    <p class="mb-0"><?php echo e($pengajuan->jenisBantuan?->nama ?? '-'); ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Nilai Pengajuan</p>
                                    <p class="mb-0">Rp <?php echo e(number_format($pengajuan->nilai, 0, ',', '.')); ?></p>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->lokasi): ?>
                                    <div class="col-12">
                                        <p class="text-small text-uppercase text-muted mb-1">Lokasi</p>
                                        <p class="mb-0"><?php echo e($pengajuan->lokasi); ?></p>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->catatan): ?>
                                    <div class="col-12">
                                        <p class="text-small text-uppercase text-muted mb-1">Catatan</p>
                                        <p class="mb-0 text-muted fst-italic"><?php echo e($pengajuan->catatan); ?></p>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted mb-0">Data pengajuan tidak tersedia.</p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card h-100">
                    <div class="card-body py-3">
                        <h2 class="small-title mb-3">Detail Verifikasi</h2>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi): ?>
                            <div class="row g-2">
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Nilai Rekomendasi</p>
                                    <p class="fw-semibold mb-0">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->nilai_rekomendasi !== null): ?>
                                            Rp <?php echo e(number_format($verifikasi->nilai_rekomendasi, 0, ',', '.')); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Diverifikasi Oleh</p>
                                    <p class="mb-0"><?php echo e($verifikasi->user?->nama ?? $verifikasi->user?->email ?? '-'); ?></p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Lulus Kriteria</p>
                                    <p class="mb-0">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->lulus_kriteria): ?>
                                            <span class="badge bg-success">Ya</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Tidak</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Lulus Administrasi</p>
                                    <p class="mb-0">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->lulus_administrasi): ?>
                                            <span class="badge bg-success">Ya</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Tidak</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Lulus Kesesuaian</p>
                                    <p class="mb-0">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->lulus_kesesuaian): ?>
                                            <span class="badge bg-success">Ya</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Tidak</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </p>
                                </div>
                                <div class="col-6">
                                    <p class="text-small text-uppercase text-muted mb-1">Sesuai Program Pemda</p>
                                    <p class="mb-0">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->sesuai_program_pemda): ?>
                                            <span class="badge bg-success">Ya</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Tidak</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </p>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->catatan): ?>
                                    <div class="col-12">
                                        <p class="text-small text-uppercase text-muted mb-1">Catatan Verifikator</p>
                                        <p class="mb-0 text-muted fst-italic"><?php echo e($verifikasi->catatan); ?></p>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted mb-0">Belum ada data verifikasi.</p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        
        <?php $dokumen = $bast->getFirstMedia('dokumen'); $fotos = $bast->getMedia('foto'); ?>
        <div class="row mb-5">
            <div class="col-lg-4 mb-3 mb-lg-0">
                <div class="card h-100">
                    <div class="card-body py-3">
                        <h2 class="small-title mb-3">Dokumen PDF</h2>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($dokumen): ?>
                            <a href="<?php echo e($dokumen->getUrl()); ?>" target="_blank" class="btn btn-sm btn-outline-danger btn-icon btn-icon-start">
                                <i data-acorn-icon="file-text"></i>
                                <span><?php echo e($dokumen->file_name); ?></span>
                            </a>
                        <?php else: ?>
                            <p class="text-muted mb-0">Tidak ada dokumen.</p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card h-100">
                    <div class="card-body py-3">
                        <h2 class="small-title mb-3">Foto <span class="text-muted fw-normal">(<?php echo e($fotos->count()); ?>)</span></h2>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($fotos->count()): ?>
                            <div class="row g-2">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-4 col-md-3 col-lg-2">
                                        <a href="<?php echo e($foto->getUrl()); ?>" target="_blank">
                                            <img src="<?php echo e($foto->getUrl()); ?>" alt="<?php echo e($foto->file_name); ?>"
                                                 class="img-fluid rounded" style="height: 80px; width: 100%; object-fit: cover;" />
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted mb-0">Tidak ada foto.</p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/bast/show.blade.php ENDPATH**/ ?>