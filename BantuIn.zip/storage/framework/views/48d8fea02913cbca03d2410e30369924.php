<!DOCTYPE html>
<html lang="en" data-url-prefix="/">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <title><?php echo e(config('app.name')); ?> | <?php echo e($title); ?></title>
    <meta name="description" content="<?php echo e($description); ?>"/>
    <?php echo $__env->make('components.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="h-100">
<div id="root" class="h-100">
    <!-- Background Start -->
    
    <!-- Background End -->

    <div class="container-fluid p-0 h-100 position-relative">
        <div class="row g-0 h-100">
            <!-- Left Side Start -->
            <div class="offset-0 col-12 d-none d-lg-flex col-lg h-lg-100">
                <?php echo $__env->yieldContent('content_left'); ?>
            </div>
            <!-- Left Side End -->

            <!-- Right Side Start -->
            <div class="col-12 col-lg-auto h-100 pb-4 px-4 pt-0 p-lg-0">
                <?php echo $__env->yieldContent('content_right'); ?>
            </div>
            <!-- Right Side End -->
        </div>
    </div>
</div>

<?php echo $__env->make('components.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('sweetalert::alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('components.livewire-swal-listener', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/layouts/layout_full.blade.php ENDPATH**/ ?>