<?php $__env->startSection('title', $pengajuan ? 'Edit Pengajuan' : 'Tambah Pengajuan'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Content Start -->
<div class="col">
    <div class="page-title-container mb-3">
        <div class="row">
            <div class="col mb-2">
                <h1 class="mb-2 pb-0 display-4">
                    <?php echo e($pengajuan ? 'Edit Pengajuan' : 'Tambah Pengajuan '); ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($pengajuan)): ?>
                    <strong><?php echo e(\Illuminate\Support\Str::of($jenis)->replace('_', ' ')->title()); ?></strong>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </h1>
                <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                    <ul class="breadcrumb pt-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('pengajuan-opd.index')); ?>">Pengajuan OPD</a></li>
                        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e($pengajuan ? 'Edit' : 'Tambah'); ?></a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-12 col-md-5 d-flex align-items-start justify-content-end">
                <a href="<?php echo e(route('pengajuan-opd.index')); ?>" class="btn btn-outline-primary btn-icon btn-icon-start w-100 w-md-auto">
                    <i data-acorn-icon="arrow-left"></i>
                    <span>Kembali</span>
                </a>
            </div>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </ul>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php
    $detail = $pengajuan;
    $mediaPengajuan = $pengajuan?->getFirstMedia('pengajuan');
    $isEdit = (bool) $pengajuan;
    $route = $isEdit ? route('pengajuan-opd.update', $pengajuan) : route('pengajuan-opd.store');
    $method = $isEdit ? 'PUT' : 'POST';
    // $jenis = old('jenis', $pengajuan?->jenis?->value ?? request('jenis', ''));
    $isBansos = $jenis === \App\Enums\JenisPengajuan::BANSOS->value;
    $isBantuanKelompok = $jenis === \App\Enums\JenisPengajuan::BANTUAN_KELOMPOK->value;
    $pendudukIsValidMap = $pendudukIsValidMap ?? [];
    $simpanDiblokir = $simpanDiblokir ?? false;
    $kelompokSimpanDiblokir = $kelompokSimpanDiblokir ?? false;
    $anggotaBelumTerverifikasi = $anggotaBelumTerverifikasi ?? collect();
    $detailPendudukForIndividu = $detailPendudukForIndividu ?? null;
    $pendudukIndividuInitial = $detailPendudukForIndividu
        ? ['id' => $detailPendudukForIndividu->id, 'is_valid' => (bool) $detailPendudukForIndividu->is_valid]
        : null;
    $jpbVal = old('jenis_penerima_bantuan', $pengajuan?->jenis_penerima_bantuan?->value ?? \App\Enums\JenisPenerimaBantuan::NON_INDIVIDU->value);
    $isNonIndividuJpb = $jpbVal === \App\Enums\JenisPenerimaBantuan::NON_INDIVIDU->value;
    $isIndividuKeluargaJpb = in_array($jpbVal, [\App\Enums\JenisPenerimaBantuan::INDIVIDU->value, \App\Enums\JenisPenerimaBantuan::KELUARGA->value], true);
    $hideKelompokTarget = ! $isNonIndividuJpb;
    $hidePendudukIndividuTarget = $isBansos || ! $isIndividuKeluargaJpb;
    $hidePendudukBansosTarget = ! ($isBansos && $isIndividuKeluargaJpb);
    ?>

    <form action="<?php echo e($route); ?>" method="POST" class="needs-validation" id="formPengajuan" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field($method); ?>

        <div class="card mb-4">
            <div class="card-body">
                <div class="row g-3">
                    <input type="hidden" name="jenis" value="<?php echo e($jenis); ?>">

                    <div class="col-12">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-6 col-sm-12 <?php echo e($isBansos ? '' : 'd-none'); ?>">
                                <label class="form-label text-small text-uppercase fw-semibold" for="jenis_penerima_bantuan">Jenis penerima bantuan <span class="text-danger">*</span></label>
                                <select name="jenis_penerima_bantuan" id="jenis_penerima_bantuan" class="form-select <?php $__errorArgs = ['jenis_penerima_bantuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = \App\Enums\JenisPenerimaBantuan::cases(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jpb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($jpb->value); ?>" <?php if(old('jenis_penerima_bantuan', $pengajuan?->jenis_penerima_bantuan?->value ?? \App\Enums\JenisPenerimaBantuan::NON_INDIVIDU->value) === $jpb->value): echo 'selected'; endif; ?>>
                                            <?php echo e($jpb->getDescription()); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['jenis_penerima_bantuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div class="<?php echo e($isBansos ? 'col-md-6 col-sm-12' : 'col-12'); ?>" id="wrap-kolom-penerima-target">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isBansos): ?>
                                    <div id="wrap-penduduk" class="<?php echo e($hidePendudukBansosTarget ? 'd-none' : ''); ?>">
                                        <label class="form-label text-small text-uppercase">Penduduk <span class="text-danger">*</span></label>
                                        <select name="penduduk_id" id="penduduk_id" class="form-select <?php $__errorArgs = ['penduduk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="">Pilih Penduduk</option>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pendudukList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p->id); ?>" <?php echo e(old('penduduk_id', $selectedPendudukId ?? null) == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama); ?> (<?php echo e($p->nik); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </select>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['penduduk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <div id="wrap-kelompok" class="<?php echo e($hideKelompokTarget ? 'd-none' : ''); ?>">
                                    <label class="form-label text-small text-uppercase" for="organisasi_id">Kelompok <span class="text-danger">*</span></label>
                                    <select name="organisasi_id" id="organisasi_id" class="form-select <?php $__errorArgs = ['organisasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="">Pilih Kelompok</option>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $kelompokList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id); ?>" <?php echo e(old('organisasi_id', $pengajuan?->organisasi_id) == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </select>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['organisasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                <div id="wrap-penduduk-individu" class="<?php echo e($hidePendudukIndividuTarget ? 'd-none' : ''); ?>">
                                    <label class="form-label text-small text-uppercase fw-semibold" for="penduduk_id_individu">Penduduk (cari NIK / nama) <span class="text-danger">*</span></label>
                                    <select name="penduduk_id" id="penduduk_id_individu" class="form-select <?php $__errorArgs = ['penduduk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="Ketik minimal 2 karakter NIK atau nama">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($detailPendudukForIndividu): ?>
                                            <option value="<?php echo e($detailPendudukForIndividu->id); ?>" selected><?php echo e($detailPendudukForIndividu->nama); ?> — <?php echo e($detailPendudukForIndividu->nik); ?></option>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </select>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['penduduk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    <div class="form-text">Pencarian berdasarkan NIK atau nama penduduk.</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isBantuanKelompok && $anggotaBelumTerverifikasi->isNotEmpty()): ?>
                    <div class="col-12">
                        <div class="alert alert-warning border-0 shadow-sm mb-0">
                            <div class="fw-semibold mb-2">
                                <i data-acorn-icon="user" data-acorn-size="18" class="me-1 align-middle"></i>
                                Anggota kelompok yang data penduduknya belum terverifikasi (is_valid)
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Nama</th>
                                            <th>NIK</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $anggotaBelumTerverifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row['nama']); ?></td>
                                            <td><?php echo e($row['nik']); ?></td>
                                            <td>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row['status'] === 'Tidak Valid'): ?>
                                                    <span class="badge bg-danger">Tidak Valid</span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning text-dark">Belum Diverifikasi</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <p class="text-muted text-small mb-0 mt-2">Selesaikan verifikasi data penduduk anggota di halaman administrasi penduduk/kelompok sebelum menyimpan pengajuan.</p>
                        </div>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">Judul Usulan <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="judul" required
                            value="<?php echo e(old('judul', $detail?->judul ?? '')); ?>" placeholder="Judul usulan bantuan" />
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <label class="form-label text-small text-uppercase">Kecamatan</label>
                        <select name="kecamatan_id" id="kecamatan_id" class="form-select <?php $__errorArgs = ['kecamatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih Kecamatan</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kecamatan->id); ?>" <?php echo e(old('kecamatan_id', $pengajuan?->desa?->kecamatan_id) == $kecamatan->id ? 'selected' : ''); ?>>
                                <?php echo e($kecamatan->nama); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['kecamatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <label class="form-label text-small text-uppercase">Desa</label>
                        <select name="desa_id" id="desa_id" class="form-select <?php $__errorArgs = ['desa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih Desa</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan?->desa_id): ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ($pengajuan->desa->kecamatan->desa ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($desa->id); ?>" <?php echo e(old('desa_id', $pengajuan->desa_id) == $desa->id ? 'selected' : ''); ?>>
                                <?php echo e($desa->nama); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['desa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">Lokasi Detail Usulan (opsional)</label>
                        <textarea class="form-control <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lokasi" rows="2"><?php echo e(old('lokasi', $detail->lokasi ?? '')); ?></textarea>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">
                            Nilai Usulan (Rp) <span class="text-danger">*</span>
                        </label>
                        <input
                            type="text"
                            class="form-control <?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="nilai"
                            id="nilai"
                            min="0"
                            step="0.01"
                            required
                            value="<?php echo e(old('nilai', isset($detail) ? number_format($detail->nilai, 0, ',', '.') : '0')); ?>"
                            inputmode="numeric"
                            autocomplete="off" />
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">File Pengajuan (PDF)</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['file_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file_pengajuan" accept="application/pdf">
                        <small class="text-muted">Format PDF, maksimal 5 MB.</small>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mediaPengajuan): ?>
                        <div class="mt-2">
                            <a href="<?php echo e($mediaPengajuan->getUrl()); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-primary">
                                <i data-acorn-icon="eye"></i> Lihat file saat ini
                            </a>
                            <div class="text-muted text-small mt-1 mb-0"><?php echo e($mediaPengajuan->file_name); ?></div>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['file_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <script>
                        document.addEventListener("DOMContentLoaded", function() {
                            const nilaiInput = document.getElementById('nilai');
                            nilaiInput.addEventListener('input', function(e) {
                                let value = this.value.replace(/[^,\d]/g, '').toString();
                                if (!value) {
                                    this.value = '';
                                    return;
                                }
                                let split = value.split(',');
                                let sisa = split[0].length % 3;
                                let rupiah = split[0].substr(0, sisa);
                                let ribuan = split[0].substr(sisa).match(/\d{3}/g);
                                if (ribuan) {
                                    rupiah += (sisa ? '.' : '') + ribuan.join('.');
                                }
                                this.value = rupiah + (split[1] !== undefined ? ',' + split[1] : '');
                            });

                            // On form submit, remove formatting so the value is numeric
                            nilaiInput.form && nilaiInput.form.addEventListener('submit', function() {
                                let val = nilaiInput.value.replace(/\./g, '').replace(',', '.');
                                nilaiInput.value = val;
                            });
                        });
                    </script>

                </div>

                <div class="d-flex flex-wrap align-items-center gap-2 mt-5">
                    <button type="submit" id="btnSimpanPengajuan" class="btn btn-primary" <?php if($simpanDiblokir): ?> disabled aria-disabled="true" <?php endif; ?>>Simpan</button>
                    <a href="<?php echo e(route('pengajuan-opd.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($simpanDiblokir): ?>
                <p id="hintSimpanDiblokir" class="text-muted text-small mt-2 mb-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isBansos): ?>
                        Penduduk yang dipilih belum terverifikasi (kolom is_valid). Selesaikan verifikasi data penduduk terlebih dahulu.
                    <?php elseif(old('jenis_penerima_bantuan', $pengajuan?->jenis_penerima_bantuan?->value ?? \App\Enums\JenisPenerimaBantuan::NON_INDIVIDU->value) !== \App\Enums\JenisPenerimaBantuan::NON_INDIVIDU->value): ?>
                        Penduduk yang dipilih belum terverifikasi (is_valid). Selesaikan verifikasi data penduduk terlebih dahulu.
                    <?php else: ?>
                        Masih ada anggota kelompok yang data penduduknya belum diverifikasi. Selesaikan verifikasi seluruh anggota terlebih dahulu.
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </p>
                <?php else: ?>
                <p id="hintSimpanDiblokir" class="text-muted text-small mt-2 mb-0 d-none"></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </form>
</div>
<!-- Page Content End -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_vendor'); ?>
<script src="<?php echo e(asset('js/vendor/select2.full.min.js')); ?>"></script>
<script src="<?php echo e($cdn ?? asset('vendor/sweetalert/sweetalert.all.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_page'); ?>
<script>
    $(function() {
        var BANSOS = '<?php echo e(\App\Enums\JenisPengajuan::BANSOS->value); ?>';
        var BANTUAN_KELOMPOK = '<?php echo e(\App\Enums\JenisPengajuan::BANTUAN_KELOMPOK->value); ?>';
        var jenisPengajuan = '<?php echo e($jenis); ?>';
        var pendudukIsValidMap = <?php echo json_encode($pendudukIsValidMap, 15, 512) ?>;
        var kelompokSimpanDiblokir = <?php echo e($kelompokSimpanDiblokir ? 'true' : 'false'); ?>;
        var NON_INDIVIDU_JPB = '<?php echo e(\App\Enums\JenisPenerimaBantuan::NON_INDIVIDU->value); ?>';
        var INDIVIDU_JPB = '<?php echo e(\App\Enums\JenisPenerimaBantuan::INDIVIDU->value); ?>';
        var KELUARGA_JPB = '<?php echo e(\App\Enums\JenisPenerimaBantuan::KELUARGA->value); ?>';
        var pendudukIndividuInitial = <?php echo json_encode($pendudukIndividuInitial, 15, 512) ?>;
        window._pendudukIndividuIsValid = null;

        function updateSimpanBlokir() {
            var blokir = false;
            var hint = '';
            var jp = $('#jenis_penerima_bantuan').val();

            if (jenisPengajuan === BANSOS) {
                var pid = $('#penduduk_id').val();
                if (pid && pendudukIsValidMap[pid] !== true) {
                    blokir = true;
                    hint = 'Penduduk yang dipilih belum terverifikasi (kolom is_valid). Selesaikan verifikasi data penduduk terlebih dahulu.';
                }
            } else if (jp === NON_INDIVIDU_JPB && kelompokSimpanDiblokir) {
                blokir = true;
                hint = 'Masih ada anggota kelompok yang data penduduknya belum diverifikasi. Selesaikan verifikasi seluruh anggota terlebih dahulu.';
            } else if (jp === INDIVIDU_JPB || jp === KELUARGA_JPB) {
                var pidI = $('#penduduk_id_individu').val();
                if (pidI) {
                    var ok = null;
                    if (pendudukIndividuInitial && String(pendudukIndividuInitial.id) === String(pidI)) {
                        ok = pendudukIndividuInitial.is_valid;
                    } else if (typeof window._pendudukIndividuIsValid === 'boolean') {
                        ok = window._pendudukIndividuIsValid;
                    }
                    if (ok === false) {
                        blokir = true;
                        hint = 'Penduduk yang dipilih belum terverifikasi (is_valid). Selesaikan verifikasi data penduduk terlebih dahulu.';
                    }
                }
            }
            $('#btnSimpanPengajuan').prop('disabled', blokir).attr('aria-disabled', blokir ? 'true' : 'false');
            var $hint = $('#hintSimpanDiblokir');
            if (blokir && hint) {
                $hint.removeClass('d-none').text(hint);
            } else {
                $hint.addClass('d-none').text('');
            }
        }

        <?php
        $kecamatansData = $kecamatans->map(function($kecamatan) {
            return [
                'id' => $kecamatan->id,
                'nama' => $kecamatan->nama,
                'desa' => $kecamatan->desa->map(function($desa) {
                    return [
                        'id' => $desa->id,
                        'nama' => $desa->nama
                    ];
                })->values()->all(),
            ];
        })->values()->all();
        ?>
        var kecamatansData = <?php echo json_encode($kecamatansData, 15, 512) ?>;

        function loadDesaByKecamatan(kecamatanId, selectedDesaId) {
            var desaSelect = $('#desa_id');
            if (desaSelect.data('select2')) {
                desaSelect.select2('destroy');
            }
            desaSelect.empty();
            desaSelect.append('<option value="">Pilih Desa</option>');
            if (kecamatanId) {
                var selectedKecamatan = kecamatansData.find(function(k) {
                    return String(k.id) === String(kecamatanId);
                });
                if (selectedKecamatan && selectedKecamatan.desa) {
                    selectedKecamatan.desa.forEach(function(desa) {
                        var sel = selectedDesaId && String(selectedDesaId) === String(desa.id) ? 'selected' : '';
                        desaSelect.append('<option value="' + desa.id + '" ' + sel + '>' + desa.nama + '</option>');
                    });
                }
            }
            desaSelect.select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih Desa',
                allowClear: true
            });
        }

        $('#jenis_penerima_bantuan').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih jenis penerima',
            allowClear: false,
            width: '100%'
        });
        if ($('#jenis_bantuan_id').length) {
            $('#jenis_bantuan_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih Jenis Bantuan',
                allowClear: true
            });
        }

        function togglePenerimaBantuan() {
            var jp = $('#jenis_penerima_bantuan').val();
            var isNonIndividu = (jp === NON_INDIVIDU_JPB);
            var isIndividuAtauKeluarga = (jp === INDIVIDU_JPB || jp === KELUARGA_JPB);
            var isBansosFlow = (jenisPengajuan === BANSOS);

            if (isBansosFlow && $('#wrap-penduduk').length) {
                if (isNonIndividu) {
                    $('#wrap-penduduk').addClass('d-none');
                    $('#wrap-kelompok').removeClass('d-none');
                    $('#wrap-penduduk-individu').addClass('d-none');
                    $('#penduduk_id').prop('disabled', true).prop('required', false);
                    $('#organisasi_id').prop('disabled', false).prop('required', true);
                    $('#penduduk_id_individu').prop('disabled', true).prop('required', false);
                } else if (isIndividuAtauKeluarga) {
                    $('#wrap-penduduk').removeClass('d-none');
                    $('#wrap-kelompok').addClass('d-none');
                    $('#wrap-penduduk-individu').addClass('d-none');
                    $('#penduduk_id').prop('disabled', false).prop('required', true);
                    $('#organisasi_id').prop('disabled', true).prop('required', false);
                    $('#penduduk_id_individu').prop('disabled', true).prop('required', false);
                }
                if ($('#wrap-jenis-bantuan').length) {
                    $('#wrap-jenis-bantuan').toggle(jenisPengajuan === BANTUAN_KELOMPOK);
                }
                if ($('#jenis_bantuan_id').length) {
                    $('#jenis_bantuan_id').prop('required', jenisPengajuan === BANTUAN_KELOMPOK);
                }
                return;
            }

            if ($('#wrap-penduduk').length) {
                $('#wrap-penduduk').addClass('d-none');
                $('#penduduk_id').prop('disabled', true);
            }

            if (isNonIndividu) {
                $('#wrap-kelompok').removeClass('d-none');
                $('#wrap-penduduk-individu').addClass('d-none');
                $('#organisasi_id').prop('disabled', false).prop('required', true);
                $('#penduduk_id_individu').prop('disabled', true).prop('required', false);
            } else if (isIndividuAtauKeluarga) {
                $('#wrap-kelompok').addClass('d-none');
                $('#wrap-penduduk-individu').removeClass('d-none');
                $('#organisasi_id').prop('disabled', true).prop('required', false);
                $('#penduduk_id_individu').prop('disabled', false).prop('required', true);
            }

            if ($('#wrap-jenis-bantuan').length) {
                $('#wrap-jenis-bantuan').toggle(jenisPengajuan === BANTUAN_KELOMPOK);
            }
            if ($('#jenis_bantuan_id').length) {
                $('#jenis_bantuan_id').prop('required', jenisPengajuan === BANTUAN_KELOMPOK);
            }
        }

        togglePenerimaBantuan();

        $('#organisasi_id').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Kelompok',
            allowClear: true
        });
        if ($('#penduduk_id').length) {
            $('#penduduk_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih Penduduk',
                allowClear: true
            });
            $('#penduduk_id').on('change', function() {
                updateSimpanBlokir();
            });
        }

        $('#penduduk_id_individu').select2({
            theme: 'bootstrap4',
            placeholder: 'Ketik minimal 2 karakter NIK atau nama',
            allowClear: true,
            width: '100%',
            minimumInputLength: 2,
            ajax: {
                url: "<?php echo e(route('pengajuan-opd.penduduk-search')); ?>",
                delay: 250,
                data: function (params) {
                    return { q: params.term || '' };
                },
                processResults: function (data) {
                    return data;
                }
            }
        });
        $('#penduduk_id_individu').on('select2:select', function (e) {
            window._pendudukIndividuIsValid = e.params.data.is_valid === true;
            updateSimpanBlokir();
        });
        $('#penduduk_id_individu').on('select2:clear', function () {
            window._pendudukIndividuIsValid = null;
            updateSimpanBlokir();
        });
        if (pendudukIndividuInitial) {
            window._pendudukIndividuIsValid = pendudukIndividuInitial.is_valid === true;
        }

        $('#kecamatan_id').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Kecamatan',
            allowClear: true
        });
        $('#desa_id').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Desa',
            allowClear: true
        });

        var initialKecamatanId = $('#kecamatan_id').val();
        var initialDesaId = $('#desa_id').val();
        if (initialKecamatanId) {
            loadDesaByKecamatan(initialKecamatanId, initialDesaId);
        }

        $('#kecamatan_id').on('change', function() {
            var kecamatanId = $(this).val();
            if (kecamatanId) {
                loadDesaByKecamatan(kecamatanId);
            } else {
                var desaSelect = $('#desa_id');
                if (desaSelect.data('select2')) {
                    desaSelect.select2('destroy');
                }
                desaSelect.empty();
                desaSelect.append('<option value="">Pilih Desa</option>');
                desaSelect.select2({
                    theme: 'bootstrap4',
                    placeholder: 'Pilih Desa',
                    allowClear: true
                });
            }
        });

        $('#jenis_penerima_bantuan').on('change', function () {
            togglePenerimaBantuan();
            updateSimpanBlokir();
        });
        updateSimpanBlokir();

        $('#formPengajuan').on('submit', function(e) {
            $('#organisasi_id').prop('disabled', false);
            $('#penduduk_id_individu').prop('disabled', false);
            var jp = $('#jenis_penerima_bantuan').val();
            if (jp === NON_INDIVIDU_JPB) {
                $('#penduduk_id_individu').prop('disabled', true);
            } else {
                $('#organisasi_id').prop('disabled', true);
            }

            if ($('#btnSimpanPengajuan').prop('disabled')) {
                e.preventDefault();
                $('#organisasi_id').prop('disabled', $('#jenis_penerima_bantuan').val() !== NON_INDIVIDU_JPB);
                $('#penduduk_id_individu').prop('disabled', $('#jenis_penerima_bantuan').val() === NON_INDIVIDU_JPB);
                return;
            }
            e.preventDefault();
            var form = this;
            Swal.fire({
                title: '<?php echo e($pengajuan ? "Perbarui Pengajuan" : "Simpan Pengajuan"); ?>',
                text: 'Apakah Anda yakin ingin <?php echo e($pengajuan ? "memperbarui" : "menyimpan"); ?> pengajuan ini?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, <?php echo e($pengajuan ? "perbarui" : "simpan"); ?>',
                cancelButtonText: 'Batal'
            }).then(function(result) {
                if (result.isConfirmed) {
                    $('#organisasi_id').prop('disabled', false);
                    $('#penduduk_id_individu').prop('disabled', false);
                    var jpx = $('#jenis_penerima_bantuan').val();
                    if (jpx === NON_INDIVIDU_JPB) {
                        $('#penduduk_id_individu').prop('disabled', true);
                    } else {
                        $('#organisasi_id').prop('disabled', true);
                    }
                    form.submit();
                } else {
                    $('#organisasi_id').prop('disabled', $('#jenis_penerima_bantuan').val() !== NON_INDIVIDU_JPB);
                    $('#penduduk_id_individu').prop('disabled', $('#jenis_penerima_bantuan').val() === NON_INDIVIDU_JPB);
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('components.form_validation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/pengajuan-opd/form.blade.php ENDPATH**/ ?>