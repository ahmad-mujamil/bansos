<?php $__env->startSection('title', 'Pengajuan'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Content Start -->
    <div class="col">
        <div class="page-title-container mb-3">
            <div class="row">
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4">Pengajuan</h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">Pengajuan</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-12 col-md-5 d-flex align-items-start justify-content-end">
                    <a href="<?php echo e(route('pengajuan.create')); ?>" class="btn btn-primary btn-icon btn-icon-start w-100 w-md-auto">
                        <i data-acorn-icon="plus"></i>
                        <span>Tambah Pengajuan</span>
                    </a>
                </div>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('info')): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?php echo e(session('info')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="card">
            <div class="card-body">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->isEmpty()): ?>
                    <p class="text-muted mb-0">Belum ada pengajuan. Klik <strong>Tambah Pengajuan</strong> untuk membuat pengajuan baru.</p>
                <?php else: ?>
                    <div class="row mb-3">
                        <div class="col-12 col-md-4 mb-3">
                            <label for="filter-status" class="form-label text-muted text-small text-uppercase">Filter Status</label>
                            <select id="filter-status" class="form-select form-select-sm">
                                <option value="all" selected>Semua</option>
                                <option value="<?php echo e(\App\Enums\PengajuanStatus::DRAFT->value); ?>">Draft</option>
                                <option value="<?php echo e(\App\Enums\PengajuanStatus::DIAJUKAN->value); ?>">Diajukan</option>
                                <option value="<?php echo e(\App\Enums\PengajuanStatus::DISETUJUI->value); ?>">Disetujui</option>
                                <option value="<?php echo e(\App\Enums\PengajuanStatus::DITOLAK->value); ?>">Ditolak</option>
                            </select>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th class="text-muted text-small text-uppercase">Kode</th>
                                    <th class="text-muted text-small text-uppercase">Judul Usulan</th>
                                    <th class="text-muted text-small text-uppercase">Lokasi</th>
                                    <th class="text-muted text-small text-uppercase">Status</th>
                                    <th class="text-muted text-small text-uppercase">Tanggal</th>
                                    <th class="text-muted text-small text-uppercase w-10">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $detail = $p; ?>
                                    <tr data-status="<?php echo e($p->status->value); ?>">
                                        <td><?php echo e($p->kode_pengajuan); ?></td>
                                        <td><?php echo e($detail?->judul ?? '-'); ?></td>
                                        <td><?php echo e($detail?->lokasi ?? '-'); ?></td>
                                        <td>
                                            <?php
                                                $status = $p->status;
                                            ?>
                                            <span class="badge bg-<?php echo e($status?->badgeColor() ?? 'secondary'); ?>"><?php echo e($status->getDescription()); ?></span>
                                        </td>
                                        <td><?php echo e($p->created_at->translatedFormat('d M Y')); ?></td>
                                        <td>
                                            <div class="d-flex gap-1">
                                                <a href="<?php echo e(route('pengajuan.show', $p)); ?>" class="btn btn-sm btn-outline-primary" title="Lihat">Lihat</a>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($p->canEdit()): ?>
                                                    <a href="<?php echo e(route('pengajuan.edit', $p)); ?>" class="btn btn-sm btn-outline-secondary" title="Edit">Edit</a>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($p->canSubmit()): ?>
                                                    <form action="<?php echo e(route('pengajuan.submit', $p)); ?>" method="POST" class="d-inline form-ajukan-pengajuan">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-sm btn-success" title="Ajukan">Ajukan</button>
                                                    </form>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page Content End -->
<?php $__env->stopSection(); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$pengajuan->isEmpty()): ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2-bootstrap4.min.css')); ?>">
    <style>
        #filter-status + .select2-container--bootstrap4 .select2-selection--single {
            height: 31px;
        }
        #filter-status + .select2-container--bootstrap4 .select2-selection--single .select2-selection__rendered {
            line-height: 31px;
            padding-top: 0;
            padding-bottom: 0;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php $__env->startPush('js_vendor'); ?>
    <script src="<?php echo e($cdn ?? asset('vendor/sweetalert/sweetalert.all.js')); ?>"></script>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$pengajuan->isEmpty()): ?>
        <script src="<?php echo e(asset('js/vendor/select2.full.min.js')); ?>"></script>
        <script>
            $(function () {
                var $filter = $('#filter-status');
                $filter.select2({
                    theme: 'bootstrap4',
                    width: '100%',
                    minimumResultsForSearch: Infinity
                });

                function applyFilter() {
                    var value = $filter.val();
                    var showAll = !value || value === 'all';
                    $('table.table tbody tr[data-status]').each(function () {
                        var rowStatus = $(this).attr('data-status') || '';
                        $(this).toggle(showAll || rowStatus === value);
                    });
                }

                $filter.on('change', applyFilter);
                applyFilter();
            });
        </script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_page'); ?>
    <script>
        (function () {
            document.querySelectorAll('form.form-ajukan-pengajuan').forEach(function (form) {
                form.addEventListener('submit', function (e) {
                    e.preventDefault();
                    var f = this;
                    Swal.fire({
                        title: 'Ajukan Pengajuan',
                        text: 'Apakah Anda yakin ingin mengajukan pengajuan ini?',
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonText: 'Ya, ajukan',
                        cancelButtonText: 'Batal'
                    }).then(function (result) {
                        if (result.isConfirmed) f.submit();
                    });
                });
            });
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/pengajuan/index.blade.php ENDPATH**/ ?>