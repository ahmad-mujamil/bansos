<?php $__env->startSection('title', 'Detail Pengguna'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col">
        <div class="page-title-container mb-3">
            <div class="row">
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4">Detail Pengguna</h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('verifikasi-pengguna.index')); ?>">Verifikasi Pengguna</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;">Detail</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-12 col-md-5 d-flex align-items-start justify-content-end gap-2">
                    <a href="<?php echo e(route('verifikasi-pengguna.index')); ?>" class="btn btn-outline-secondary btn-icon btn-icon-start w-100 w-md-auto">
                        <i data-acorn-icon="arrow-left"></i>
                        <span>Kembali</span>
                    </a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$user->is_active && $user->userDetail): ?>
                        <a href="<?php echo e(route('verifikasi-pengguna.aktifkan', $user->id)); ?>" data-confirm-aktifkan="true" class="btn btn-success btn-icon btn-icon-start w-100 w-md-auto">
                            <i data-acorn-icon="check"></i>
                            <span>Aktifkan Pengguna</span>
                        </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h2 class="small-title mb-3">Data Akun</h2>
                <div class="row">
                    <div class="col-md-6 col-lg-4 mb-3">
                        <label class="form-label text-muted text-small text-uppercase">Nama</label>
                        <p class="mb-0"><?php echo e($user->nama); ?></p>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <label class="form-label text-muted text-small text-uppercase">Email</label>
                        <p class="mb-0"><?php echo e($user->email); ?></p>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <label class="form-label text-muted text-small text-uppercase">Username</label>
                        <p class="mb-0"><?php echo e($user->username); ?></p>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <label class="form-label text-muted text-small text-uppercase">Role</label>
                        <p class="mb-0"><?php echo e($user->role->getDescription()); ?></p>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <label class="form-label text-muted text-small text-uppercase">Status Akun</label>
                        <p class="mb-0">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->is_active): ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Belum aktif</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->userDetail): ?>
            <?php $d = $user->userDetail; ?>
            <div class="card mb-4">
                <div class="card-body">
                    <h2 class="small-title mb-3">Data Detail (Profil)</h2>
                    <div class="row">
                        <div class="col-md-6 col-lg-4 mb-3">
                            <label class="form-label text-muted text-small text-uppercase">Jenis User</label>
                            <p class="mb-0"><?php echo e($d->type->getDescription()); ?></p>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <label class="form-label text-muted text-small text-uppercase">Nama User / Kontak</label>
                            <p class="mb-0"><?php echo e($d->nama_user ?? '-'); ?></p>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <label class="form-label text-muted text-small text-uppercase">No. Telepon</label>
                            <p class="mb-0"><?php echo e($d->phone ?? '-'); ?></p>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <label class="form-label text-muted text-small text-uppercase">Desa</label>
                            <p class="mb-0"><?php echo e($d->desa?->nama ?? '-'); ?></p>
                        </div>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <label class="form-label text-muted text-small text-uppercase">Kecamatan</label>
                            <p class="mb-0"><?php echo e($d->desa?->kecamatan?->nama ?? '-'); ?></p>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label text-muted text-small text-uppercase">Alamat</label>
                            <p class="mb-0"><?php echo e($d->alamat ?? '-'); ?></p>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($d->type->value === \App\Enums\JenisUser::INDIVIDUAL->value): ?>
                            <div class="col-md-6 col-lg-4 mb-3">
                                <label class="form-label text-muted text-small text-uppercase">Nama Lengkap (Personal)</label>
                                <p class="mb-0"><?php echo e($d->nama_personal ?? '-'); ?></p>
                            </div>
                            <div class="col-md-6 col-lg-4 mb-3">
                                <label class="form-label text-muted text-small text-uppercase">NIK</label>
                                <p class="mb-0"><?php echo e($d->nik ?? '-'); ?></p>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($d->file_ktp): ?>
                                <div class="col-md-6 col-lg-4 mb-3">
                                    <label class="form-label text-muted text-small text-uppercase">KTP</label>
                                    <p class="mb-0"><a href="<?php echo e(asset('storage/' . $d->file_ktp)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">Lihat berkas</a></p>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php else: ?>
                            <div class="col-md-6 col-lg-4 mb-3">
                                <label class="form-label text-muted text-small text-uppercase">Nama Lembaga</label>
                                <p class="mb-0"><?php echo e($d->nama_lembaga ?? '-'); ?></p>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($d->file_surat_kuasa): ?>
                                <div class="col-md-6 col-lg-4 mb-3">
                                    <label class="form-label text-muted text-small text-uppercase">Surat Kuasa</label>
                                    <p class="mb-0"><a href="<?php echo e(asset('storage/' . $d->file_surat_kuasa)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">Lihat berkas</a></p>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <label class="form-label text-muted text-small text-uppercase">Status Verifikasi Detail</label>
                            <p class="mb-0">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($d->verification_status->value === 'approved'): ?>
                                    <span class="badge bg-success"><?php echo e($d->verification_status->getDescription()); ?></span>
                                <?php elseif($d->verification_status->value === 'rejected'): ?>
                                    <span class="badge bg-danger"><?php echo e($d->verification_status->getDescription()); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark"><?php echo e($d->verification_status->getDescription()); ?></span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </p>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($d->verification_note): ?>
                            <div class="col-12 mb-3">
                                <label class="form-label text-muted text-small text-uppercase">Catatan Verifikasi</label>
                                <p class="mb-0"><?php echo e($d->verification_note); ?></p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="card mb-4">
                <div class="card-body">
                    <p class="text-muted mb-0">Pengguna ini belum mengisi data detail.</p>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_vendor'); ?>
    <script src="<?php echo e($cdn ?? asset('vendor/sweetalert/sweetalert.all.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js_page'); ?>
    <script>
        document.addEventListener('click', function(e) {
            var el = e.target.closest('[data-confirm-aktifkan]');
            if (!el) return;
            e.preventDefault();
            var href = el.getAttribute('href');
            Swal.fire({
                title: 'Aktifkan Pengguna',
                text: 'Apakah Anda yakin ingin mengaktifkan pengguna ini?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, aktifkan',
                cancelButtonText: 'Batal'
            }).then(function(result) {
                if (result.isConfirmed) window.location.href = href;
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/verifikasi-pengguna/show.blade.php ENDPATH**/ ?>