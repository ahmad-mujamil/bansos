<?php $__env->startSection('title', $pengajuan ? 'Edit Pengajuan' : 'Tambah Pengajuan'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Content Start -->
<div class="col">
    <div class="page-title-container mb-3">
        <div class="row">
            <div class="col mb-2">
                <h1 class="mb-2 pb-0 display-4"><?php echo e($pengajuan ? 'Edit Pengajuan' : 'Tambah Pengajuan'); ?></h1>
                <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                    <ul class="breadcrumb pt-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('pengajuan.index')); ?>">Pengajuan</a></li>
                        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e($pengajuan ? 'Edit' : 'Tambah'); ?></a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-12 col-md-5 d-flex align-items-start justify-content-end">
                <a href="<?php echo e(route('pengajuan.index')); ?>" class="btn btn-outline-primary btn-icon btn-icon-start w-100 w-md-auto">
                    <i data-acorn-icon="arrow-left"></i>
                    <span>Kembali</span>
                </a>
            </div>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </ul>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php
    $detail = $pengajuan;
    $mediaPengajuan = $pengajuan?->getFirstMedia('pengajuan');
    $isEdit = (bool) $pengajuan;
    $route = $isEdit ? route('pengajuan.update', $pengajuan) : route('pengajuan.store');
    $method = $isEdit ? 'PUT' : 'POST';
    // $jenis = old('jenis', $pengajuan?->jenis?->value ?? request('jenis', ''));
    $isBansos = $jenis === \App\Enums\JenisPengajuan::BANSOS->value;
    $isBantuanKelompok = $jenis === \App\Enums\JenisPengajuan::BANTUAN_KELOMPOK->value;
    $pendudukIsValidMap = $pendudukIsValidMap ?? [];
    $simpanDiblokir = $simpanDiblokir ?? false;
    $kelompokSimpanDiblokir = $kelompokSimpanDiblokir ?? false;
    $anggotaBelumTerverifikasi = $anggotaBelumTerverifikasi ?? collect();
    ?>

    <form action="<?php echo e($route); ?>" method="POST" class="needs-validation" id="formPengajuan" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field($method); ?>

        <div class="card mb-4">
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6 col-sm-12">
                        <label class="form-label text-small text-uppercase">Jenis <span class="text-danger">*</span></label>
                        <input type="hidden" name="jenis" value="<?php echo e($jenis); ?>">
                        <select id="jenis" class="form-select <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>
                            <option value="">Pilih Jenis</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $jenisOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($opt->value); ?>" <?php echo e('bantuan_kelompok' == $opt->value ? 'selected' : ''); ?>>
                                <?php echo e($opt->getDescription()); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 col-sm-12" id="wrap-penduduk" style="<?php echo e(!$isBansos ? 'display:none;' : ''); ?>">
                        <label class="form-label text-small text-uppercase">Penduduk <span class="text-danger">*</span></label>
                        <select name="penduduk_id" id="penduduk_id" class="form-select <?php $__errorArgs = ['penduduk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih Penduduk</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pendudukList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php echo e(old('penduduk_id', $selectedPendudukId ?? null) == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama); ?> (<?php echo e($p->nik); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['penduduk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-6 col-sm-12" id="wrap-kelompok" style="<?php echo e($isBansos ? 'display:none;' : ''); ?>">


                        <label class="form-label text-small text-uppercase">Kelompok <span class="text-danger">*</span></label>
                        <select name="kelompok_id" id="kelompok_id" class="form-select <?php $__errorArgs = ['kelompok_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>
                            <option value="">Pilih Kelompok</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $kelompokList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e(old('kelompok_id', auth()->user()->userDetail?->organisasi_id) == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['kelompok_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isBantuanKelompok && $anggotaBelumTerverifikasi->isNotEmpty()): ?>
                    <div class="col-12">
                        <div class="alert alert-warning border-0 shadow-sm mb-0">
                            <div class="fw-semibold mb-2">
                                <i data-acorn-icon="user" data-acorn-size="18" class="me-1 align-middle"></i>
                                Anggota kelompok yang data penduduknya belum terverifikasi (is_valid)
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered bg-white mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Nama</th>
                                            <th>NIK</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $anggotaBelumTerverifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row['nama']); ?></td>
                                            <td><?php echo e($row['nik']); ?></td>
                                            <td>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row['status'] === 'Tidak Valid'): ?>
                                                    <span class="badge bg-danger">Tidak Valid</span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning text-dark">Belum Diverifikasi</span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <p class="text-muted text-small mb-0 mt-2">Selesaikan verifikasi data penduduk anggota di halaman administrasi penduduk/kelompok sebelum menyimpan pengajuan.</p>
                        </div>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">Judul Usulan <span class="text-danger">*</span></label>
                        <input type="text" class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="judul" required
                            value="<?php echo e(old('judul', $detail?->judul ?? '')); ?>" placeholder="Judul usulan bantuan" />
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <input type="hidden" name="opd_id" value="<?php echo e(auth()->user()->userDetail?->organisasi?->opd_id ?? ''); ?>">
                    <input type="hidden" name="organisasi_id" value="<?php echo e(auth()->user()->userDetail?->organisasi_id ?? ''); ?>">



                    <div class="col-md-6 col-sm-12">
                        <label class="form-label text-small text-uppercase">Kecamatan</label>
                        <select name="kecamatan_id" id="kecamatan_id" class="form-select <?php $__errorArgs = ['kecamatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih Kecamatan</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kecamatan->id); ?>" <?php echo e(old('kecamatan_id', $pengajuan?->desa?->kecamatan_id) == $kecamatan->id ? 'selected' : ''); ?>>
                                <?php echo e($kecamatan->nama); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['kecamatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <label class="form-label text-small text-uppercase">Desa</label>
                        <select name="desa_id" id="desa_id" class="form-select <?php $__errorArgs = ['desa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="">Pilih Desa</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan?->desa_id): ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ($pengajuan->desa->kecamatan->desa ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($desa->id); ?>" <?php echo e(old('desa_id', $pengajuan->desa_id) == $desa->id ? 'selected' : ''); ?>>
                                <?php echo e($desa->nama); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['desa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">Lokasi Detail Usulan (opsional)</label>
                        <textarea class="form-control <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lokasi" rows="2"><?php echo e(old('lokasi', $detail->lokasi ?? '')); ?></textarea>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">
                            Nilai Usulan (Rp) <span class="text-danger">*</span>
                        </label>
                        <input
                            type="text"
                            class="form-control <?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="nilai"
                            id="nilai"
                            min="0"
                            step="0.01"
                            required
                            value="<?php echo e(old('nilai', isset($detail) ? number_format($detail->nilai, 0, ',', '.') : '0')); ?>"
                            inputmode="numeric"
                            autocomplete="off" />
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="col-md-12 col-sm-12">
                        <label class="form-label text-small text-uppercase">File Pengajuan (PDF)</label>
                        <input type="file" class="form-control <?php $__errorArgs = ['file_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file_pengajuan" accept="application/pdf">
                        <small class="text-muted">Format PDF, maksimal 5 MB.</small>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($mediaPengajuan): ?>
                        <div class="mt-2">
                            <a href="<?php echo e($mediaPengajuan->getUrl()); ?>" target="_blank" class="text-primary fw-semibold">
                                Lihat file saat ini: <?php echo e($mediaPengajuan->file_name); ?>

                            </a>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['file_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <script>
                        document.addEventListener("DOMContentLoaded", function() {
                            const nilaiInput = document.getElementById('nilai');
                            nilaiInput.addEventListener('input', function(e) {
                                let value = this.value.replace(/[^,\d]/g, '').toString();
                                if (!value) {
                                    this.value = '';
                                    return;
                                }
                                let split = value.split(',');
                                let sisa = split[0].length % 3;
                                let rupiah = split[0].substr(0, sisa);
                                let ribuan = split[0].substr(sisa).match(/\d{3}/g);
                                if (ribuan) {
                                    rupiah += (sisa ? '.' : '') + ribuan.join('.');
                                }
                                this.value = rupiah + (split[1] !== undefined ? ',' + split[1] : '');
                            });

                            // On form submit, remove formatting so the value is numeric
                            nilaiInput.form && nilaiInput.form.addEventListener('submit', function() {
                                let val = nilaiInput.value.replace(/\./g, '').replace(',', '.');
                                nilaiInput.value = val;
                            });
                        });
                    </script>

                </div>

                <div class="d-flex flex-wrap align-items-center gap-2 mt-5">
                    <button type="submit" id="btnSimpanPengajuan" class="btn btn-primary" <?php if($simpanDiblokir): ?> disabled aria-disabled="true" <?php endif; ?>>Simpan</button>
                    <a href="<?php echo e(route('pengajuan.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($simpanDiblokir): ?>
                <p id="hintSimpanDiblokir" class="text-muted text-small mt-2 mb-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isBansos): ?>
                        Penduduk yang dipilih belum terverifikasi (kolom is_valid). Selesaikan verifikasi data penduduk terlebih dahulu.
                    <?php else: ?>
                        Masih ada anggota kelompok yang data penduduknya belum diverifikasi. Selesaikan verifikasi seluruh anggota terlebih dahulu.
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </p>
                <?php else: ?>
                <p id="hintSimpanDiblokir" class="text-muted text-small mt-2 mb-0 d-none"></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </form>
</div>
<!-- Page Content End -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_vendor'); ?>
<script src="<?php echo e(asset('js/vendor/select2.full.min.js')); ?>"></script>
<script src="<?php echo e($cdn ?? asset('vendor/sweetalert/sweetalert.all.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_page'); ?>
<script>
    $(function() {
        var BANSOS = '<?php echo e(\App\Enums\JenisPengajuan::BANSOS->value); ?>';
        var BANTUAN_KELOMPOK = '<?php echo e(\App\Enums\JenisPengajuan::BANTUAN_KELOMPOK->value); ?>';
        var jenisPengajuan = '<?php echo e($jenis); ?>';
        var pendudukIsValidMap = <?php echo json_encode($pendudukIsValidMap, 15, 512) ?>;
        var kelompokSimpanDiblokir = <?php echo e($kelompokSimpanDiblokir ? 'true' : 'false'); ?>;

        function updateSimpanBlokir() {
            var blokir = false;
            var hint = '';
            if (jenisPengajuan === BANSOS) {
                var pid = $('#penduduk_id').val();
                if (pid && pendudukIsValidMap[pid] !== true) {
                    blokir = true;
                    hint = 'Penduduk yang dipilih belum terverifikasi (kolom is_valid). Selesaikan verifikasi data penduduk terlebih dahulu.';
                }
            } else if (kelompokSimpanDiblokir) {
                blokir = true;
                hint = 'Masih ada anggota kelompok yang data penduduknya belum diverifikasi. Selesaikan verifikasi seluruh anggota terlebih dahulu.';
            }
            $('#btnSimpanPengajuan').prop('disabled', blokir).attr('aria-disabled', blokir ? 'true' : 'false');
            var $hint = $('#hintSimpanDiblokir');
            if (blokir && hint) {
                $hint.removeClass('d-none').text(hint);
            } else {
                $hint.addClass('d-none').text('');
            }
        }

        <?php
        $kecamatansData = $kecamatans->map(function($kecamatan) {
            return [
                'id' => $kecamatan->id,
                'nama' => $kecamatan->nama,
                'desa' => $kecamatan->desa->map(function($desa) {
                    return [
                        'id' => $desa->id,
                        'nama' => $desa->nama
                    ];
                })->values()->all(),
            ];
        })->values()->all();
        ?>
        var kecamatansData = <?php echo json_encode($kecamatansData, 15, 512) ?>;

        function loadDesaByKecamatan(kecamatanId, selectedDesaId) {
            var desaSelect = $('#desa_id');
            if (desaSelect.data('select2')) {
                desaSelect.select2('destroy');
            }
            desaSelect.empty();
            desaSelect.append('<option value="">Pilih Desa</option>');
            if (kecamatanId) {
                var selectedKecamatan = kecamatansData.find(function(k) {
                    return String(k.id) === String(kecamatanId);
                });
                if (selectedKecamatan && selectedKecamatan.desa) {
                    selectedKecamatan.desa.forEach(function(desa) {
                        var sel = selectedDesaId && String(selectedDesaId) === String(desa.id) ? 'selected' : '';
                        desaSelect.append('<option value="' + desa.id + '" ' + sel + '>' + desa.nama + '</option>');
                    });
                }
            }
            desaSelect.select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih Desa',
                allowClear: true
            });
        }

        $('#jenis').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Jenis',
            allowClear: false
        });
        if ($('#jenis_bantuan_id').length) {
            $('#jenis_bantuan_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Pilih Jenis Bantuan',
                allowClear: true
            });
        }
        $('#kelompok_id').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Kelompok',
            allowClear: true
        });
        $('#penduduk_id').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Penduduk',
            allowClear: true
        });
        $('#penduduk_id').on('change', function() {
            updateSimpanBlokir();
        });
        $('#kecamatan_id').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Kecamatan',
            allowClear: true
        });
        $('#desa_id').select2({
            theme: 'bootstrap4',
            placeholder: 'Pilih Desa',
            allowClear: true
        });

        var initialKecamatanId = $('#kecamatan_id').val();
        var initialDesaId = $('#desa_id').val();
        if (initialKecamatanId) {
            loadDesaByKecamatan(initialKecamatanId, initialDesaId);
        }

        $('#kecamatan_id').on('change', function() {
            var kecamatanId = $(this).val();
            if (kecamatanId) {
                loadDesaByKecamatan(kecamatanId);
            } else {
                var desaSelect = $('#desa_id');
                if (desaSelect.data('select2')) {
                    desaSelect.select2('destroy');
                }
                desaSelect.empty();
                desaSelect.append('<option value="">Pilih Desa</option>');
                desaSelect.select2({
                    theme: 'bootstrap4',
                    placeholder: 'Pilih Desa',
                    allowClear: true
                });
            }
        });

        function toggleJenis() {
            var jenis = $('#jenis').val();
            var isBansos = (jenis === BANSOS);
            var isBantuanKelompok = (jenis === BANTUAN_KELOMPOK);

            $('#wrap-kelompok').toggle(!isBansos);
            $('#wrap-penduduk').toggle(isBansos);
            $('#wrap-jenis-bantuan').toggle(isBantuanKelompok);
            $('#jenis_bantuan_id').prop('required', isBantuanKelompok);
            $('#kelompok_id').prop('required', !isBansos);
            $('#penduduk_id').prop('required', isBansos);
        }

        $('#jenis').on('change', toggleJenis);
        toggleJenis();
        updateSimpanBlokir();

        $('#formPengajuan').on('submit', function(e) {
            if ($('#btnSimpanPengajuan').prop('disabled')) {
                e.preventDefault();
                return;
            }
            e.preventDefault();
            var form = this;
            Swal.fire({
                title: '<?php echo e($pengajuan ? "Perbarui Pengajuan" : "Simpan Pengajuan"); ?>',
                text: 'Apakah Anda yakin ingin <?php echo e($pengajuan ? "memperbarui" : "menyimpan"); ?> pengajuan ini?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, <?php echo e($pengajuan ? "perbarui" : "simpan"); ?>',
                cancelButtonText: 'Batal'
            }).then(function(result) {
                if (result.isConfirmed) form.submit();
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('components.form_validation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/pengajuan/form.blade.php ENDPATH**/ ?>