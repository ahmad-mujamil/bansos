<div>
    <form wire:submit.prevent="save" class="needs-validation">
        <div class="card-body">
            <p class="text-muted mb-4">Silakan isi alur untuk 3 kategori bantuan yang tampil di landing page.</p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $alur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriIndex => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border rounded p-3 mb-4" wire:key="alur-kategori-<?php echo e($item['kategori']); ?>">
                    <h4 class="mb-3"><?php echo e($item['label']); ?></h4>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $item['steps']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stepIndex => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row border rounded mx-0 mb-3 p-3" wire:key="alur-step-<?php echo e($item['kategori']); ?>-<?php echo e($stepIndex); ?>">
                            <div class="col-12 mb-2 d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">Step <?php echo e($stepIndex + 1); ?></h6>
                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-danger"
                                    wire:click="removeStep(<?php echo e($kategoriIndex); ?>, <?php echo e($stepIndex); ?>)"
                                    <?php if(count($item['steps']) <= 1): echo 'disabled'; endif; ?>
                                >
                                    Hapus Step
                                </button>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label text-small text-uppercase">Judul</label>
                                <input type="text" class="form-control" wire:model="alur.<?php echo e($kategoriIndex); ?>.steps.<?php echo e($stepIndex); ?>.judul" required>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ["alur.$kategoriIndex.steps.$stepIndex.judul"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label text-small text-uppercase">Icon (Material Symbols)</label>
                                <input type="text" class="form-control" wire:model="alur.<?php echo e($kategoriIndex); ?>.steps.<?php echo e($stepIndex); ?>.icon" placeholder="contoh: fact_check" list="alur-icon-suggestions">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ["alur.$kategoriIndex.steps.$stepIndex.icon"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                <small class="text-muted d-block mt-1">
                                    Isi nama icon Material Symbols (opsional). Jika dikosongkan, sistem memilih icon otomatis dari judul/deskripsi step.
                                </small>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label text-small text-uppercase">Deskripsi</label>
                                <textarea class="form-control" rows="3" wire:model="alur.<?php echo e($kategoriIndex); ?>.steps.<?php echo e($stepIndex); ?>.deskripsi" required></textarea>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ["alur.$kategoriIndex.steps.$stepIndex.deskripsi"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <button type="button" class="btn btn-outline-primary btn-sm" wire:click="addStep(<?php echo e($kategoriIndex); ?>)">
                        Tambah Step
                    </button>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ["alur.$kategoriIndex.steps"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small mt-2"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="alert alert-light border mb-4">
                <div class="fw-semibold mb-2">Hint pemilihan icon</div>
                <div class="small text-muted mb-2">
                    Gunakan nama icon dari Material Symbols (huruf kecil + underscore). Contoh yang umum:
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <code>person_search</code>
                    <code>fact_check</code>
                    <code>gavel</code>
                    <code>payments</code>
                    <code>assignment</code>
                    <code>task_alt</code>
                    <code>approval</code>
                    <code>handshake</code>
                </div>
                <div class="small mt-2">
                    Referensi icon:
                    <a href="https://fonts.google.com/icons" target="_blank" rel="noopener noreferrer">fonts.google.com/icons</a>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                <span wire:loading.remove>Simpan Alur Bantuan</span>
                <span wire:loading>Menyimpan...</span>
            </button>
        </div>
    </form>

    <datalist id="alur-icon-suggestions">
        <option value="person_search"></option>
        <option value="fact_check"></option>
        <option value="gavel"></option>
        <option value="payments"></option>
        <option value="assignment"></option>
        <option value="task_alt"></option>
        <option value="approval"></option>
        <option value="handshake"></option>
        <option value="inventory_2"></option>
        <option value="campaign"></option>
    </datalist>
</div>
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/livewire/kelola/alur-bantuan-form.blade.php ENDPATH**/ ?>