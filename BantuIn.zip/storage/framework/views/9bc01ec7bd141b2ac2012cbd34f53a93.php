<?php $__env->startSection('title', 'Semua Berita'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-10 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
            <h1 class="text-4xl font-bold text-primary">Berita</h1>
            <p class="text-on-surface-variant mt-2">Update penyaluran dan program bantuan sosial.</p>
        </div>
        <a href="<?php echo e(route('landing')); ?>#news" class="text-primary font-semibold inline-flex items-center gap-2 hover:underline">
            <span class="material-symbols-outlined text-lg">arrow_back</span> Kembali ke beranda
        </a>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($beritas->isEmpty()): ?>
        <div class="rounded-xl border border-outline-variant bg-surface-container-low p-12 text-center text-on-surface-variant">
            Belum ada berita terbit.
    <?php else: ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('berita.publik.show', ['berita' => $berita->slug])); ?>" class="group bg-surface-container-lowest rounded-xl overflow-hidden border border-transparent hover:border-outline-variant hover:shadow-md transition-all duration-300 flex flex-col">
                    <div class="h-48 overflow-hidden bg-surface-container">
                        <?php $img = $berita->getFirstMediaUrl('featured'); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($img !== ''): ?>
                            <img src="<?php echo e($img); ?>" alt="<?php echo e($berita->judul); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>
                        <?php else: ?>
                            <div class="w-full h-full flex items-center justify-center text-on-surface-variant text-sm">Tanpa gambar</div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="p-6 space-y-3 flex-1 flex flex-col">
                        <span class="text-xs font-bold text-primary-container tracking-widest uppercase"><?php echo e($berita->kategoriBerita?->nama ?? '—'); ?></span>
                        <h2 class="text-xl font-bold text-primary line-clamp-2 group-hover:text-primary-container transition-colors"><?php echo e($berita->judul); ?></h2>
                        <p class="text-on-surface-variant text-sm line-clamp-3 flex-1"><?php echo e($berita->ringkasan); ?></p>
                        <div class="flex items-center text-slate-400 text-xs pt-2">
                            <span class="material-symbols-outlined text-sm mr-1">calendar_today</span>
                            <?php echo e($berita->published_at?->translatedFormat('d M Y')); ?>

                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <div class="mt-12 flex justify-center">
            <?php echo e($beritas->withQueryString()->links('vendor.pagination.tailwind')); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public-bantuin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/berita/publik-index.blade.php ENDPATH**/ ?>