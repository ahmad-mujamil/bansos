<?php $__env->startPush('js_page'); ?>
    <script>
        _initBootstrapValidation();
        function _initBootstrapValidation() {

            const forms = document.querySelectorAll('.needs-validation');
            Array.prototype.slice.call(forms).forEach(function (form) {
                form.addEventListener(
                    'submit',
                    function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    },
                    false,
                );
            });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/components/form_validation.blade.php ENDPATH**/ ?>