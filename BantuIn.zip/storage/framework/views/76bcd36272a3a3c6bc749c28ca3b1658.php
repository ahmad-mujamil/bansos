<?php $__env->startSection('title', 'Dokumentasi Realisasi'); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $status = $pengajuan->status;
        $badge  = $status?->badgeColor() ?? 'secondary';
        $catatan = $pengajuan->catatan_verifikator ?? $pengajuan->catatan;
        $realisasi = $pengajuan->realisasi;
        $routeForm = $realisasi ? route('realisasi.update', $pengajuan) : route('realisasi.store', $pengajuan);
        $methodForm = $realisasi ? 'PUT' : 'POST';
    ?>
    <div class="col">
        <div class="page-title-container mb-3">
            <div class="row">
                <div class="col mb-2">
                    <h1 class="mb-2 pb-0 display-4" id="title">Dokumentasi Realisasi</h1>
                    <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                        <ul class="breadcrumb pt-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('realisasi.index')); ?>">Realisasi</a></li>
                            <li class="breadcrumb-item"><a href="javascript:;"><?php echo e($pengajuan->kode_pengajuan); ?></a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-12 col-md-5 d-flex align-items-start justify-content-end">
                    <a href="<?php echo e(route('realisasi.index')); ?>" class="btn btn-outline-secondary btn-icon btn-icon-start w-100 w-md-auto">
                        <i data-acorn-icon="arrow-left"></i>
                        <span>Kembali</span>
                    </a>
                </div>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="alert alert-danger border-0 shadow-sm">
                <ul class="mb-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <h2 class="small-title mb-4">Informasi Pengajuan <?php echo e($pengajuan->kode_pengajuan); ?></h2>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Judul</span>
                        <div class="fw-semibold"><?php echo e($pengajuan->judul ?? '—'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Jenis bantuan</span>
                        <div class="fw-semibold"><?php echo e($pengajuan->jenisBantuan?->nama ?? '—'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Nilai usulan</span>
                        <div class="fw-semibold">Rp <?php echo e(number_format((float) $pengajuan->nilai, 0, ',', '.')); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Status</span>
                        <div>
                            <span class="badge bg-<?php echo e($badge); ?>"><?php echo e($pengajuan->status->getDescription()); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Tanggal dibuat</span>
                        <div><?php echo e($pengajuan->created_at?->translatedFormat('d F Y H:i') ?? '—'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Pengaju</span>
                        <div><?php echo e($pengajuan->user?->nama ?? ($pengajuan->user?->email ?? '—')); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Kelompok</span>
                        <div class="fw-semibold"><?php echo e($pengajuan->organisasi?->nama ?? '—'); ?></div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Lokasi kegiatan</span>
                        <div class="fw-semibold">
                            <?php echo e($pengajuan->lokasi ?? '—'); ?>,
                            <?php echo e($pengajuan->desa?->nama ?? '—'); ?>,
                            <?php echo e($pengajuan->desa?->kecamatan?->nama ?? '—'); ?>

                        </div>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->verifikasiPengajuan?->nilai_rekomendasi !== null): ?>
                        <div class="col-md-4 mb-3">
                            <span class="text-small text-uppercase text-muted">Nilai rekomendasi</span>
                            <div class="fw-semibold text-primary">
                                Rp <?php echo e(number_format((float) $pengajuan->verifikasiPengajuan->nilai_rekomendasi, 0, ',', '.')); ?>

                            </div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->verified_at): ?>
                        <div class="col-md-4 mb-3">
                            <span class="text-small text-uppercase text-muted">Diverifikasi pada</span>
                            <div><?php echo e($pengajuan->verified_at->translatedFormat('d F Y H:i')); ?></div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <span class="text-small text-uppercase text-muted">Diverifikasi oleh</span>
                            <div><?php echo e($pengajuan->verifiedBy?->nama ?? ($pengajuan->verifiedBy?->email ?? '—')); ?></div>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <div class="col-md-4 mb-3">
                        <span class="text-small text-uppercase text-muted">Lampiran pengajuan</span>
                        <div>
                            <?php $lampiran = $pengajuan->getFirstMedia('pengajuan'); ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lampiran): ?>
                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e($lampiran->getUrl()); ?>" target="_blank" rel="noopener noreferrer">
                                    Lihat dokumen
                                </a>
                                <div class="text-muted small mt-1"><?php echo e($lampiran->file_name); ?></div>
                            <?php else: ?>
                                <div class="text-muted">—</div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($catatan): ?>
                    <div class="mt-3">
                        <span class="text-small text-uppercase text-muted">Catatan</span>
                        <div class="alert alert-light border mt-1 mb-0"><?php echo e($catatan); ?></div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->bast || $pengajuan->pemeriksa->isNotEmpty()): ?>
            <div class="row g-3 mb-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->bast): ?>
                    <div class="<?php echo e($pengajuan->pemeriksa->isNotEmpty() ? 'col-lg-8' : 'col-12'); ?>">
                        <div class="card h-100 border-start border-4 border-primary shadow-sm">
                            <div class="card-body">
                                <div class="d-flex flex-wrap align-items-start justify-content-between gap-2 mb-3">
                                    <div>
                                        <h2 class="small-title mb-1">Berita Acara Serah Terima (BAST)</h2>
                                        <p class="text-muted small mb-0">Data serah terima bantuan untuk pengajuan ini.</p>
                                    </div>
                                    <span class="badge bg-primary align-self-center">Terverifikasi &amp; Diserahterimakan</span>
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <span class="text-small text-uppercase text-muted">Nomor BAST</span>
                                        <div class="fw-semibold fs-5"><?php echo e($pengajuan->bast->nomor); ?></div>
                                    </div>
                                    <div class="col-md-4">
                                        <span class="text-small text-uppercase text-muted">Tanggal BAST</span>
                                        <div class="fw-semibold"><?php echo e($pengajuan->bast->tanggal?->translatedFormat('d F Y') ?? '—'); ?></div>
                                    </div>
                                    <div class="col-md-4">
                                        <span class="text-small text-uppercase text-muted">Penerima</span>
                                        <div class="fw-semibold"><?php echo e($pengajuan->bast->penerima); ?></div>
                                    </div>
                                    <div class="col-md-6">
                                        <span class="text-small text-uppercase text-muted">Dicatat oleh</span>
                                        <div><?php echo e($pengajuan->bast->user?->nama ?? ($pengajuan->bast->user?->email ?? '—')); ?></div>
                                    </div>
                                </div>
                                <?php
                                    $bastDokumen = $pengajuan->bast->getFirstMedia('dokumen');
                                    $bastFotos = $pengajuan->bast->getMedia('foto');
                                ?>
                                <div class="border-top pt-3 mt-2">
                                    <span class="text-small text-uppercase text-muted d-block mb-3">Dokumentasi BAST</span>
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <span class="text-small text-uppercase text-muted d-block mb-2">Dokumen PDF</span>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bastDokumen): ?>
                                                <a href="<?php echo e($bastDokumen->getUrl()); ?>" target="_blank" rel="noopener noreferrer"
                                                   class="btn btn-sm btn-outline-danger btn-icon btn-icon-start">
                                                    <i data-acorn-icon="file-text" data-acorn-size="16"></i>
                                                    <span class="text-truncate" style="max-width: 12rem;"><?php echo e($bastDokumen->file_name); ?></span>
                                                </a>
                                            <?php else: ?>
                                                <div class="text-muted small mb-0">Tidak ada dokumen.</div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                        <div class="col-md-8">
                                            <span class="text-small text-uppercase text-muted d-block mb-2">
                                                Foto <span class="fw-normal">(<?php echo e($bastFotos->count()); ?>)</span>
                                            </span>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bastFotos->isNotEmpty()): ?>
                                                <div class="d-flex flex-wrap gap-2">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $bastFotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e($foto->getUrl()); ?>" target="_blank" rel="noopener noreferrer" class="d-block">
                                                            <img src="<?php echo e($foto->getUrl()); ?>" alt="<?php echo e($foto->file_name); ?>"
                                                                 class="rounded border"
                                                                 style="height: 72px; width: 72px; object-fit: cover;" />
                                                        </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <div class="text-muted small mb-0">Tidak ada foto.</div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->pemeriksa->isNotEmpty()): ?>
                    <div class="<?php echo e($pengajuan->bast ? 'col-lg-4' : 'col-12'); ?>">
                        <div class="card h-100 border-start border-4 border-primary shadow-sm">
                            <div class="card-body d-flex flex-column">
                                <div class="mb-3">
                                    <h2 class="small-title mb-1">Pemeriksa</h2>
                                    <p class="text-muted small mb-0">Tim pemeriksa pengajuan ini.</p>
                                </div>
                                <div class="table-responsive flex-grow-1">
                                    <table class="table table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>Nama</th>
                                                <th>NIP</th>
                                                <th>Jabatan</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pengajuan->pemeriksa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemeriksa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="fw-semibold"><?php echo e($pemeriksa->nama); ?></td>
                                                    <td><?php echo e($pemeriksa->nip); ?></td>
                                                    <td><?php echo e($pemeriksa->jabatan); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div class="card mb-5 shadow-sm overflow-hidden">
            <div class="card-header bg-primary text-white py-3 border-0">
                <div class="d-flex align-items-center gap-2">
                    <i data-acorn-icon="notebook-1" class="text-white" data-acorn-size="20"></i>
                    <div>
                        <h2 class="small-title text-white mb-0">Unggah dokumentasi realisasi</h2>
                        <p class="mb-0 text-white opacity-75 small">Laporan kegiatan dan bukti pelaksanaan bantuan (PDF).</p>
                    </div>
                </div>
            </div>
            <form novalidate enctype="multipart/form-data" action="<?php echo e($routeForm); ?>" method="POST" class="needs-validation">
                <?php echo csrf_field(); ?>
                <?php echo method_field($methodForm); ?>
                <div class="card-body p-4">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label text-small text-uppercase fw-semibold" for="keterangan">
                                Keterangan <span class="text-danger">*</span>
                            </label>
                            <textarea id="keterangan" name="keterangan" rows="3" required
                                      class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Ringkasan kegiatan realisasi, lokasi pelaksanaan, atau catatan penting."><?php echo e(old('keterangan', $realisasi?->keterangan ?? '')); ?></textarea>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="col-md-5 col-lg-4">
                            <label class="form-label text-small text-uppercase fw-semibold" for="tanggal_laporan">
                                Tanggal laporan <span class="text-muted fw-normal">(opsional)</span>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i data-acorn-icon="calendar" data-acorn-size="16"></i></span>
                                <input type="text" id="tanggal_laporan" autocomplete="off"
                                       class="form-control border-start-0 <?php $__errorArgs = ['tanggal_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal_laporan"
                                       value="<?php echo e(old('tanggal_laporan', $realisasi?->tanggal_laporan?->format('d-m-Y') ?? '')); ?>"
                                       placeholder="dd-mm-yyyy" />
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['tanggal_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-7 col-lg-8">
                            <label class="form-label text-small text-uppercase fw-semibold" for="dokumen">
                                Dokumen laporan (PDF)
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($realisasi)): ?>
                                    <span class="text-danger">*</span>
                                <?php else: ?>
                                    <span class="text-muted fw-normal">(opsional)</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </label>
                            <input type="file" id="dokumen" name="dokumen"
                                   class="form-control <?php $__errorArgs = ['dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   accept=".pdf,application/pdf" <?php echo e($realisasi ? '' : 'required'); ?> />
                            <div class="form-text">Satu file PDF, maks. 5 MB.</div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($realisasi && $realisasi->getMedia('laporan_kegiatan')->count()): ?>
                            <div class="col-12">
                                <span class="form-label text-small text-uppercase fw-semibold d-block mb-2">Berkas yang sudah diunggah</span>
                                <div class="d-flex flex-wrap gap-2">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $realisasi->getMedia('laporan_kegiatan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($media->getUrl()); ?>" target="_blank" rel="noopener noreferrer"
                                           class="btn btn-outline-primary btn-sm rounded-pill">
                                            <i data-acorn-icon="file-text" data-acorn-size="14" class="me-1"></i>
                                            <?php echo e($media->name); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <p class="text-muted small mt-2 mb-0">Mengunggah file baru akan mengganti semua dokumen sebelumnya.</p>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div class="d-flex flex-wrap gap-2 mt-4 pt-3 border-top">
                        <button type="submit" class="btn btn-primary btn-icon btn-icon-start">
                            <i data-acorn-icon="check"></i>
                            <span><?php echo e($realisasi ? 'Simpan perubahan' : 'Simpan dokumentasi'); ?></span>
                        </button>
                        <a href="<?php echo e(route('realisasi.index')); ?>" class="btn btn-outline-secondary">Batal</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/bootstrap-datepicker3.standalone.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js_vendor'); ?>
    <script src="<?php echo e(asset('js/vendor/datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
        $("document").ready(function () {
            $('#tanggal_laporan').datepicker({
                autoclose: true,
                format: 'dd-mm-yyyy',
                orientation: 'bottom',
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('components.form_validation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/realisasi/create.blade.php ENDPATH**/ ?>