<?php $__env->startSection('title', 'Detail Verifikasi Pengajuan'); ?>
<?php $__env->startSection('content'); ?>
<div class="col">
    <div class="page-title-container mb-3">
        <div class="row">
            <div class="col mb-2">
                <h1 class="mb-2 pb-0 display-4"><?php echo e(($laporanReadOnly ?? false) ? 'Detail Pengajuan' : 'Detail Verifikasi Pengajuan'); ?></h1>
                <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                    <ul class="breadcrumb pt-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($laporanReadOnly ?? false): ?>
                            <li class="breadcrumb-item"><a href="javascript:;">Laporan</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('laporan-pengajuan.index')); ?>">Pengajuan Kelompok</a></li>
                        <?php else: ?>
                            <li class="breadcrumb-item"><a href="javascript:;">Verifikasi</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('verifikasi-pengajuan.index')); ?>">Pengajuan
                                    Bantuan</a></li>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e($pengajuan->kode_pengajuan); ?></a></li>
                    </ul>
                </nav>
            </div>
            <div class="col-12 col-md-5 d-flex align-items-start justify-content-end gap-2">
                <a href="<?php echo e($laporanBackUrl ?? route('verifikasi-pengajuan.index')); ?>"
                    class="btn btn-outline-secondary btn-icon btn-icon-start w-100 w-md-auto">
                    <i data-acorn-icon="arrow-left"></i>
                    <span>Kembali</span>
                </a>
            </div>
        </div>
    </div>

    <?php
    $status = $pengajuan->status;
    $badge = $status?->badgeColor() ?? 'secondary';
    $catatan = $pengajuan->catatan_verifikator ?? $pengajuan->catatan;
    $laporanReadOnly = $laporanReadOnly ?? false;
    $canVerify = ! $laporanReadOnly && in_array($pengajuan->status, [\App\Enums\PengajuanStatus::DIAJUKAN], true);
    ?>

    <div class="card mb-4">
        <div class="card-body">
            <h2 class="small-title mb-4">Informasi Pengajuan <?php echo e($pengajuan->kode_pengajuan); ?></h2>
            <div class="row">

                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Judul</span>
                    <div class="fw-semibold">
                        <?php echo e($pengajuan->judul ?? '-'); ?>

                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Nilai Usulan</span>
                    <div class="fw-semibold"><?php echo e(number_format($pengajuan->nilai, 0, ',', '.')); ?></div>
                </div>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Status</span>
                    <div>
                        <span class="badge bg-<?php echo e($badge); ?>"><?php echo e($pengajuan->status->getDescription()); ?></span>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Tanggal Dibuat</span>
                    <div><?php echo e($pengajuan->created_at?->translatedFormat('d F Y H:i') ?? '-'); ?></div>
                </div>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Pengaju</span>
                    <div><?php echo e($pengajuan->user?->nama ?? ($pengajuan->user ?? '-')); ?></div>
                </div>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Kelompok</span>
                    <div class="fw-semibold"><?php echo e($pengajuan->organisasi?->nama ?? '—'); ?></div>
                </div>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Lokasi Kegiatan</span>
                    <div class="fw-semibold"><?php echo e($pengajuan->lokasi ?? '—'); ?>, <?php echo e($pengajuan->desa?->nama ?? '—'); ?>, <?php echo e($pengajuan->desa?->kecamatan?->nama ?? '—'); ?></div>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->verified_at): ?>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Diverifikasi Pada</span>
                    <div><?php echo e($pengajuan->verified_at->translatedFormat('d F Y H:i')); ?></div>
                </div>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Diverifikasi Oleh</span>
                    <div><?php echo e($pengajuan->verifiedBy?->nama ?? ($pengajuan->verifiedBy?->email ?? '-')); ?></div>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="col-md-4 mb-3">
                    <span class="text-small text-uppercase text-muted">Lampiran</span>
                    <div>
                        <?php
                        $lampiran = $pengajuan->getFirstMedia('pengajuan');
                        ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lampiran): ?>
                        <a class="btn btn-sm btn-outline-primary" href="<?php echo e($lampiran->getUrl()); ?>" target="_blank"
                            rel="noopener noreferrer">
                            Lihat Dokumen
                        </a>
                        <div class="text-muted small mt-1"><?php echo e($lampiran->file_name); ?></div>
                        <?php else: ?>
                        <div class="text-muted">-</div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($catatan): ?>
            <div class="mt-3">
                <span class="text-small text-uppercase text-muted">Catatan</span>
                <div class="alert alert-light border mt-1 mb-0"><?php echo e($catatan); ?></div>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->pemeriksa->isNotEmpty()): ?>
    <div class="card mb-4">
        <div class="card-body">
            <h2 class="small-title mb-4">Pemeriksa</h2>
            <div class="table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>NIP</th>
                            <th>Jabatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pengajuan->pemeriksa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemeriksa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-semibold"><?php echo e($pemeriksa->nama); ?></td>
                            <td><?php echo e($pemeriksa->nip); ?></td>
                            <td><?php echo e($pemeriksa->jabatan); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canVerify): ?>
    <div class="card mb-4">
        <div class="card-body">
            <h2 class="small-title mb-4">Verifikasi</h2>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('verifikasi-pengajuan-form', ['pengajuan' => $pengajuan]);

$__key = null;

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-672929126-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key);

echo $__html;

unset($__html);
unset($__key);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
    <?php else: ?>
    <?php
        $verifikasi = $pengajuan->verifikasiPengajuan;
        $baMedia = $verifikasi?->getFirstMedia('ba-verifikasi');
        $verifikasiId = $verifikasi?->id;
        $bantuanUang = $verifikasiId ? ($bantuanUangByVerifikasi[$verifikasiId] ?? collect()) : collect();
        $bantuanBarangJasa = $verifikasiId ? ($bantuanBarangJasaByVerifikasi[$verifikasiId] ?? collect()) : collect();
    ?>

    <div class="card mb-4">
        <div class="card-body">
            <h2 class="small-title mb-4">Hasil Verifikasi</h2>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi): ?>
                <div class="row g-3 mb-4">
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Lulus Kriteria</p>
                        <span class="badge bg-<?php echo e($verifikasi->lulus_kriteria ? 'success' : 'danger'); ?>"><?php echo e($verifikasi->lulus_kriteria ? 'Ya' : 'Tidak'); ?></span>
                    </div>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Lulus Administrasi</p>
                        <span class="badge bg-<?php echo e($verifikasi->lulus_administrasi ? 'success' : 'danger'); ?>"><?php echo e($verifikasi->lulus_administrasi ? 'Ya' : 'Tidak'); ?></span>
                    </div>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Lulus Kesesuaian</p>
                        <span class="badge bg-<?php echo e($verifikasi->lulus_kesesuaian ? 'success' : 'danger'); ?>"><?php echo e($verifikasi->lulus_kesesuaian ? 'Ya' : 'Tidak'); ?></span>
                    </div>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Sesuai Program Pemda</p>
                        <span class="badge bg-<?php echo e($verifikasi->sesuai_program_pemda ? 'success' : 'danger'); ?>"><?php echo e($verifikasi->sesuai_program_pemda ? 'Ya' : 'Tidak'); ?></span>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->nilai_rekomendasi !== null): ?>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Nilai Rekomendasi</p>
                        <p class="fw-semibold mb-0">Rp <?php echo e(number_format($verifikasi->nilai_rekomendasi, 0, ',', '.')); ?></p>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->rupa_bantuan): ?>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Rupa Bantuan</p>
                        <p class="mb-0"><?php echo e($verifikasi->rupa_bantuan->getDescription()); ?></p>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->disahkan_oleh): ?>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Disahkan Oleh</p>
                        <p class="mb-0"><?php echo e($verifikasi->disahkan_oleh); ?></p>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->lokasi_pengesahan): ?>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Lokasi Pengesahan</p>
                        <p class="mb-0"><?php echo e($verifikasi->lokasi_pengesahan); ?></p>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->tgl_disahkan): ?>
                    <div class="col-6 col-md-3">
                        <p class="text-small text-uppercase text-muted mb-1">Tanggal Pengesahan</p>
                        <p class="mb-0"><?php echo e($verifikasi->tgl_disahkan->translatedFormat('d F Y')); ?></p>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasi->catatan): ?>
                    <div class="col-12">
                        <p class="text-small text-uppercase text-muted mb-1">Catatan</p>
                        <div class="alert alert-light border mb-0"><?php echo e($verifikasi->catatan); ?></div>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($baMedia): ?>
                    <div class="col-12">
                        <p class="text-small text-uppercase text-muted mb-1">Dokumen BA Verifikasi</p>
                        <a href="<?php echo e($baMedia->getUrl()); ?>" target="_blank" class="btn btn-sm btn-outline-danger btn-icon btn-icon-start">
                            <i data-acorn-icon="file-text"></i>
                            <span><?php echo e($baMedia->file_name); ?></span>
                        </a>
                    </div>
                    <?php elseif(!($laporanReadOnly ?? false)): ?>
                    <div class="col-12">
                        <p class="text-small text-uppercase text-muted mb-1">Dokumen BA Verifikasi</p>
                        <a href="<?php echo e(route('verifikasi-pengajuan.download-ba-verifikasi', $pengajuan->id)); ?>" target="_blank"
                            class="btn btn-sm btn-outline-success btn-icon btn-icon-start">
                            <i data-acorn-icon="file-text"></i>
                            <span>Download BA</span>
                        </a>
                    </div>
                    <?php else: ?>
                    <div class="col-12">
                        <p class="text-small text-uppercase text-muted mb-1">Dokumen BA Verifikasi</p>
                        <span class="text-muted">Belum diunggah.</span>
                    </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bantuanUang->isNotEmpty()): ?>
                <hr>
                <h3 class="small-title mb-3 mt-4">Detail Bantuan Uang</h3>
                <?php $totalUang = $bantuanUang->sum(fn($r) => (float) $r->nilai); ?>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr>
                                <th>Penduduk</th>
                                <th class="text-end" style="width: 200px;">Nilai</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $bantuanUang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->penduduk?->nama ?? $row->penduduk_id); ?></td>
                                <td class="text-end">Rp <?php echo e(number_format((float) $row->nilai, 0, ',', '.')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th class="text-end">Total</th>
                                <th class="text-end fw-semibold">Rp <?php echo e(number_format($totalUang, 0, ',', '.')); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bantuanBarangJasa->isNotEmpty()): ?>
                <hr>
                <h3 class="small-title mb-3 mt-4">Detail Bantuan Barang / Jasa</h3>
                <?php $totalBarangJasa = $bantuanBarangJasa->sum(fn($r) => (float) $r->harga_satuan * (int) $r->qty); ?>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th style="width: 120px;">Satuan</th>
                                <th class="text-end" style="width: 70px;">Qty</th>
                                <th class="text-end" style="width: 160px;">Harga Satuan</th>
                                <th class="text-end" style="width: 180px;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $bantuanBarangJasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $subtotal = (float) $row->harga_satuan * (int) $row->qty; ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($row->nama_barang); ?></div>
                                    <div class="text-muted small"><?php echo e($row->spesifikasi); ?></div>
                                </td>
                                <td><?php echo e($row->satuan); ?></td>
                                <td class="text-end"><?php echo e($row->qty); ?></td>
                                <td class="text-end">Rp <?php echo e(number_format((float) $row->harga_satuan, 0, ',', '.')); ?></td>
                                <td class="text-end">Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="4" class="text-end">Total</th>
                                <th class="text-end fw-semibold">Rp <?php echo e(number_format($totalBarangJasa, 0, ',', '.')); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <p class="text-muted mb-0">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($laporanReadOnly && $pengajuan->status === \App\Enums\PengajuanStatus::DIAJUKAN): ?>
                        Belum diverifikasi.
                    <?php else: ?>
                        Data verifikasi tidak ditemukan.
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pengajuan->logs->isNotEmpty()): ?>
    <!-- <div class="card mb-4">
        <div class="card-body">
            <h2 class="small-title mb-4">Riwayat Aksi</h2>
            <div class="timeline">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $pengajuan->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="timeline-item">
                    <div class="timeline-content">
                        <?php
                        $badgeLog = \App\Enums\PengajuanStatus::tryFrom($log->status_to)?->badgeColor() ?? 'secondary';
                        ?>

                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div class="d-flex flex-column">
                                <div class="d-flex flex-wrap align-items-center gap-2">
                                    <span class="badge bg-light border text-dark">
                                        <i data-acorn-icon="check-circle" class="me-1"></i>
                                        <?php echo e($log->action); ?>

                                    </span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->status_to): ?>
                                    <span class="badge bg-<?php echo e($badgeLog); ?>">
                                        <?php echo e(strtoupper($log->status_to)); ?>

                                    </span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <div class="text-muted small mt-1">
                                    <?php echo e($log->created_at?->translatedFormat('d F Y, H:i') ?? '-'); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->user): ?>
                                    <span class="mx-1">•</span>
                                    <?php echo e($log->user?->nama ?? $log->user?->email); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log->catatan): ?>
                        <div class="mt-2">
                            <div class="small-title text-muted mb-1">Catatan</div>
                            <div class="alert alert-light border mb-0">
                                <?php echo e($log->catatan); ?>

                            </div>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php ($verifikasiId = $log->metadata['verifikasi_pengajuan_id'] ?? null); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($verifikasiId): ?>
                        <?php ($bantuanUang = $bantuanUangByVerifikasi[$verifikasiId] ?? collect()); ?>
                        <?php ($bantuanBarangJasa = $bantuanBarangJasaByVerifikasi[$verifikasiId] ?? collect()); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bantuanUang->isNotEmpty()): ?>
                        <div class="mt-3">
                            <?php ($totalBantuanUang = $bantuanUang->sum(fn($row) => (float) $row->nilai)); ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="small-title text-muted mb-0">Bantuan Uang</div>
                                <div class="text-muted small">Total: <span class="fw-semibold text-dark"><?php echo e(number_format((float) $totalBantuanUang, 2, ',', '.')); ?></span></div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-striped mb-0">
                                    <thead>
                                        <tr>
                                            <th>Penduduk</th>
                                            <th class="text-end" style="width: 180px;">Nilai</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $bantuanUang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row->penduduk?->nama ?? $row->penduduk_id); ?>

                                            </td>
                                            <td class="text-end">
                                                <?php echo e(number_format((float) $row->nilai, 2, ',', '.')); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th class="text-end">Total</th>
                                            <th class="text-end fw-semibold">
                                                <?php echo e(number_format((float) $totalBantuanUang, 2, ',', '.')); ?>

                                            </th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($bantuanBarangJasa->isNotEmpty()): ?>
                        <div class="mt-3">
                            <?php ($totalBarangJasa = $bantuanBarangJasa->sum(fn($row) => (float) $row->harga_satuan * (int) $row->qty)); ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="small-title text-muted mb-0">Bantuan Barang / Jasa</div>
                                <div class="text-muted small">Total: <span class="fw-semibold text-dark"><?php echo e(number_format((float) $totalBarangJasa, 2, ',', '.')); ?></span></div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-sm table-striped mb-0">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th style="width: 120px;">Satuan</th>
                                            <th class="text-end" style="width: 90px;">Qty</th>
                                            <th class="text-end" style="width: 160px;">Harga Satuan</th>
                                            <th class="text-end" style="width: 180px;">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $bantuanBarangJasa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php ($subtotal = (float) $row->harga_satuan * (int) $row->qty); ?>
                                        <tr>
                                            <td>
                                                <div class="fw-semibold"><?php echo e($row->nama_barang); ?>

                                                </div>
                                                <div class="text-muted small">
                                                    <?php echo e($row->spesifikasi); ?>

                                                </div>
                                            </td>
                                            <td><?php echo e($row->satuan); ?></td>
                                            <td class="text-end"><?php echo e($row->qty); ?></td>
                                            <td class="text-end">
                                                <?php echo e(number_format((float) $row->harga_satuan, 2, ',', '.')); ?>

                                            </td>
                                            <td class="text-end">
                                                <?php echo e(number_format((float) $subtotal, 2, ',', '.')); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="4" class="text-end">Total</th>
                                            <th class="text-end fw-semibold">
                                                <?php echo e(number_format((float) $totalBarangJasa, 2, ',', '.')); ?>

                                            </th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div> -->
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_vendor'); ?>
<script src="<?php echo e($cdn ?? asset('vendor/sweetalert/sweetalert.all.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('components.number-format', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/pages/verifikasi-pengajuan/show.blade.php ENDPATH**/ ?>