<div class="row mb-3">
    <div class="col-lg-6 col-md-6 col-sm-12">
        <label class="block text-sm font-medium mb-1 text-small text-uppercase">Kecamatan</label>
        <div>
            <select id="select-kecamatan" name="kecamatan_id" class="form-control select2">
                <option value="">-- Pilih Kecamatan --</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $kecamatanOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e($kecamatan === $item->id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </select>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['kecamatan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-12">
        <label class="block text-sm font-medium mb-1 text-small text-uppercase">Desa / Kelurahan</label>
        <div id="container-desa">
            <select id="select-desa" name="desa_id" class="form-control select2">
                <option value="">-- Pilih Desa/Kelurahan --</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $desaOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item['id']); ?>" <?php echo e($desa === $item['id'] ? 'selected' : ''); ?>><?php echo e($item['nama']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </select>
        </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['desa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2-bootstrap4.min.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js_vendor'); ?>
    <script src="<?php echo e(asset('js/vendor/select2.full.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

    <?php
        $__scriptKey = '4096776298-0';
        ob_start();
    ?>
<script>
    let isUpdatingFromLivewire = false;

    const initSelect2 = () => {
        const $kecamatan = $('#select-kecamatan');
        const $desa = $('#select-desa');

        if ($kecamatan.data('select2')) {
            $kecamatan.select2('destroy');
        }
        if ($desa.data('select2')) {
            $desa.select2('destroy');
        }

        $kecamatan.select2({
            theme: 'bootstrap4',
            placeholder: '-- Pilih Kecamatan --',
            allowClear: true,
            width: '100%'
        }).on('change', function (e) {
            if (!isUpdatingFromLivewire) {
                $wire.set('kecamatan', e.target.value);
            }
        });

        $desa.select2({
            theme: 'bootstrap4',
            placeholder: '-- Pilih Desa/Kelurahan --',
            allowClear: true,
            width: '100%'
        }).on('change', function (e) {
            if (!isUpdatingFromLivewire) {
                $wire.set('desa', e.target.value);
            }
        });
    }

    const startInit = () => {
        if (typeof $ !== 'undefined' && $.fn.select2) {
            initSelect2();
        } else {
            setTimeout(startInit, 100);
        }
    };

    startInit();

    // Re-initialize Select2 after Livewire updates
    Livewire.hook('morph.updated', () => {
        startInit();
    });

    $wire.on('resync-desa', (event) => {
        const data = Array.isArray(event) ? event[0] : event;
        const desaOptions = data.desaOptions;
        const currentDesa = data.desa;

        isUpdatingFromLivewire = true;

        const $desa = $('#select-desa');

        if ($desa.data('select2')) {
            $desa.select2('destroy');
        }

        $desa.empty().append('<option value="">-- Pilih Desa/Kelurahan --</option>');

        if (desaOptions) {
            desaOptions.forEach(function(item) {
                const option = new Option(item.nama, item.id, false, item.id == currentDesa);
                $desa.append(option);
            });
        }

        $desa.select2({
            theme: 'bootstrap4',
            placeholder: '-- Pilih Desa/Kelurahan --',
            allowClear: true,
            width: '100%'
        }).val(currentDesa).trigger('change.select2');

        setTimeout(() => {
            $desa.on('change', function (e) {
                if (!isUpdatingFromLivewire) {
                    $wire.set('desa', e.target.value);
                }
            });
            isUpdatingFromLivewire = false;
        }, 100);
    });

    $wire.on('set-kecamatan', (event) => {
        const data = Array.isArray(event) ? event[0] : event;
        const kecamatan = data.kecamatan;

        isUpdatingFromLivewire = true;
        const $kecamatan = $('#select-kecamatan');
        $kecamatan.val(kecamatan).trigger('change.select2');

        setTimeout(() => {
            isUpdatingFromLivewire = false;
        }, 100);
    });

    $wire.on('set-desa', (event) => {
        const data = Array.isArray(event) ? event[0] : event;
        const desa = data.desa;

        isUpdatingFromLivewire = true;
        const $desa = $('#select-desa');
        $desa.val(desa).trigger('change.select2');

        setTimeout(() => {
            isUpdatingFromLivewire = false;
        }, 100);
    });
</script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
<?php /**PATH /Users/zanulharir/Web/Laravel/bansos/resources/views/livewire/wilayah-select.blade.php ENDPATH**/ ?>