<?php

namespace App\Http\Requests;

use App\Enums\StatusUser;
use App\Enums\JenisUser;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class RegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // Allow guest users to register
    }

    public function rules(): array
    {

        return [
            "nama" => ["required", "string", "max:255"],
            "email" => ["required", "email", "max:255", "unique:users,email"],
            "username" => ["required", "string", "max:50", "unique:users,username"],
            "password" => ["required", "string", "min:8", "confirmed"],
            "jenis_user" => ["required", Rule::enum(JenisUser::class)],
        ];
    }

    public function messages(): array
    {
        return [
            "nama.required" => "Nama harus diisi.",
            "nama.string" => "Nama harus berupa teks.",
            "nama.max" => "Nama maksimal 255 karakter.",
            "email.required" => "Email harus diisi.",
            "email.email" => "Format email tidak valid.",
            "email.max" => "Email maksimal 255 karakter.",
            "email.unique" => "Email sudah digunakan.",
            "username.required" => "Username harus diisi.",
            "username.string" => "Username harus berupa teks.",
            "username.max" => "Username maksimal 50 karakter.",
            "username.unique" => "Username sudah digunakan.",
            "password.required" => "Password harus diisi.",
            "password.string" => "Password harus berupa teks.",
            "password.min" => "Password minimal 8 karakter.",
            "password.confirmed" => "Konfirmasi password tidak cocok.",
            "jenis_user.required" => "Jenis user harus dipilih.",
        ];
    }
}

