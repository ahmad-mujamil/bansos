<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class JenisBantuanRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check();
    }

    public function rules(): array
    {

        return [
            "nama" => ["required", "string", "max:255"]  ,
            'keterangan' => ['required', 'string'],
            "kategori" => ["required", "string"],
        ];
    }
}

