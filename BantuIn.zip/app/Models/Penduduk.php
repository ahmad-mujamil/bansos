<?php

namespace App\Models;

use App\Enums\JenisKelamin;
use App\Enums\LevelDesil;
use App\Enums\StatusPerkawinan;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\PengajuanDetail;

class Penduduk extends Model
{
    use HasUuids;

    protected $table = 'penduduk';

    protected $keyType = 'string';

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'tgl_lahir' => 'date',
            'status_perkawinan' => StatusPerkawinan::class,
            'level_desil' => LevelDesil::class,
            'jk' => JenisKelamin::class,
            'is_valid' => 'boolean',
            'validated_at' => 'datetime',
        ];
    }

    public function desa(): BelongsTo
    {
        return $this->belongsTo(Desa::class);
    }

    public function kecamatan(): BelongsTo
    {
        return $this->belongsTo(Kecamatan::class);
    }

    public function organisasiDetails(): HasMany
    {
        return $this->hasMany(OrganisasiDetail::class, 'penduduk_id');
    }

    public function pengajuanDetails(): HasMany
    {
        return $this->hasMany(PengajuanDetail::class, 'penduduk_id');
    }

    public function validatedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'validated_by');
    }

    public function labelStatusVerifikasi(): string
    {
        if ($this->is_valid) {
            return 'Terverifikasi';
        }
        if ($this->validated_at && ! $this->is_valid) {
            return 'Tidak Valid';
        }

        return 'Belum Diverifikasi';
    }
}
