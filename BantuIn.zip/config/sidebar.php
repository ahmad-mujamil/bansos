<?php

return [
    // ROLE USER
    [
        'id' => 'PROFILE_USER',
        'icon' => 'user',
        'title' => 'Profile User',
        'url' => 'javascript:;',
        'caret' => true,
        'sub_menu' => [
            [
                'id' => 'PROFILE_USER_DETAIL',
                'icon' => 'user',
                'url' => '/user-detail',
                'title' => 'Detail Data',
            ],
        ],
    ],
    [
        'id' => 'BANTUAN',
        'icon' => '',
        'title' => 'Pengajuan Bantuan',
        'url' => 'javascript:;',
        'caret' => true,
        'sub_menu' => [
            [
                'id' => 'PENGAJUAN',
                'icon' => 'book',
                'url' => '/pengajuan',
                'title' => 'Pengajuan',
            ],
            [
                'id' => 'REALISASI',
                'icon' => 'notebook-1',
                'url' => '/realisasi',
                'title' => 'Realisasi',
            ],
        ],
    ],
    [
        // ROLE OPD
        'id' => 'SIDE_MASTER_DATA',
        'icon' => '',
        'title' => 'Master Data',
        'url' => 'javascript:;',
        'caret' => true,
        'sub_menu' => [
            [
                'id' => 'USER_KELOMPOK',
                'icon' => 'user',
                'url' => '/user-kelompok',
                'title' => 'User Kelompok',
            ],
            [
                'id' => 'KELOMPOK_MASYARAKAT',
                'icon' => 'diagram-1',
                'url' => '/kelompok-masyarakat',
                'title' => 'Kelompok Masyarakat',
            ],
            [
                'id' => 'PENDUDUK',
                'icon' => 'user',
                'url' => '/penduduk',
                'title' => 'Penduduk',
            ],
        ],
    ],

    [
        'id' => 'SIDE_VERIFIKASI',
        'url' => 'javascript:;',
        'title' => 'Pengajuan & Verifikasi',
        'icon' => '',
        'caret' => true,
        'sub_menu' => [
            [
                'id' => 'PENGAJUAN_OPD',
                'icon' => 'book',
                'url' => '/pengajuan-opd',
                'title' => 'Pengajuan Bantuan',
            ],

            [
                'id' => 'VERIFY_PENGGUNA',
                'icon' => 'user',
                'url' => '/verifikasi-pengguna',
                'title' => 'Verifikasi Pengguna',
            ],
            [
                'id' => 'VERIFY_PENDUDUK',
                'icon' => 'check-square',
                'url' => '/verifikasi-penduduk',
                'title' => 'Verifikasi Penduduk',
            ],

            [
                'id' => 'VERIFY_PENGAJUAN',
                'icon' => 'form-check',
                'url' => '/verifikasi-pengajuan',
                'title' => 'Verifikasi Pengajuan',
            ],
        ],
    ],

    [
        'id' => 'BAST_DAN_BLACKLIST',
        'url' => 'javascript:;',
        'title' => 'Realisasi & Blacklist',
        'icon' => '',
        'caret' => true,
        'sub_menu' => [
            [
                'id' => 'BAST',
                'icon' => 'book',
                'url' => '/bast',
                'title' => 'BA Serah Terima',
            ],
            [
                'id' => 'BLACKLIST',
                'icon' => 'close-circle',
                'url' => '/blacklist',
                'title' => 'Blacklist Kelompok',
            ],
        ],
    ],

    [
        'id' => 'MONITORING_DAN_REALISASI',
        'url' => 'javascript:;',
        'title' => 'Monitoring & Realisasi',
        'icon' => '',
        'caret' => true,
        'sub_menu' => [
            [
                'id' => 'MONITORING',
                'icon' => 'activity',
                'url' => '/monitoring-bantuan',
                'title' => 'Monitoring Bantuan',
            ],
            [
                'id' => 'REALISASI_BANTUAN',
                'icon' => 'delivery-truck',
                'url' => '/realisasi-bantuan',
                'title' => 'Realisasi Bantuan',
            ],
            [
                'id' => 'CARI_PENDUDUK_NIK',
                'icon' => 'search',
                'url' => '/cari-penduduk-by-nik',
                'title' => 'Cari Penduduk (NIK)',
            ],
        ],
    ],
    [
        'id' => 'SIDE_LAPORAN',
        'icon' => '',
        'title' => 'Laporan',
        'url' => 'javascript:;',
        'caret' => true,
        'sub_menu' => [
            [
                'id' => 'SIDE_LAP_PENGAJUAN',
                'icon' => 'file-text',
                'url' => '/laporan-pengajuan',
                'title' => 'Pengajuan',
            ],
            [
                'id' => 'SIDE_LAP_ANGGOTA_KELOMPOK',
                'icon' => 'user',
                'url' => '/laporan-anggota-kelompok',
                'title' => 'Anggota Kelompok',
            ],
        ],
    ],
];
